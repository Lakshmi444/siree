package com.cg;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {

	
	@RequestMapping("/hello1")
	public ModelAndView sayHello()
	{
		return new ModelAndView("Login");
	}
	
	@RequestMapping(value="/showPage",method=RequestMethod.GET)
	public String showPage(Model model)
	{
		String name="Lakshmi";
		model.addAttribute("name",name);
		return "success";
	}
}
