package com.cg.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.cg.entity.Customer;
import com.cg.entity.Order;
import com.cg.dao.CustomerDao;
import com.cg.dao.OrderDao;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class InvoiceController {
	
	@Autowired
	CustomerDao customerDao;
	
	@Autowired
	OrderDao orderDao;
	@Autowired

	
	@PostMapping(value="/addcustomer",consumes= {MediaType.APPLICATION_JSON_VALUE})
	public Customer createCustomer(@RequestBody Customer customer) {
		
	Customer savedCustomer=customerDao.save(customer);
	return savedCustomer;
	
	}
	
	@GetMapping("/viewcustomer")
	public List<Customer> viewCustomer(){	
		return (List<Customer>) customerDao.findAll();
				
	}
	
	
	@PostMapping(value="/addorder",consumes= {MediaType.APPLICATION_JSON_VALUE})
	public Order createOrder(@RequestBody Order order) {
	
	Order savedOrder=orderDao.save(order);
	return savedOrder;
	
	}
	
	@GetMapping("/vieworder")
	public List<Order> viewOrder(){
		
		return (List<Order>) orderDao.findAll();
				
	}
	
	

}
