package com.cg.service;

import java.util.List;

import com.cg.entity.Order;

public interface IOrderService {
	public Order createOrder(Order order);
	public List<Order>viewOrder();


}
