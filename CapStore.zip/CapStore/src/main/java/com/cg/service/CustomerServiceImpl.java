package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.Customer;
import com.cg.dao.CustomerDao;

@Service
public class CustomerServiceImpl implements ICustomerService {
	
	@Autowired
	CustomerDao customerDao;

	
	@Override
	public Customer createCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return customerDao.save(customer);
	}

	@Override
	public List<Customer> viewCustomer() {
		// TODO Auto-generated method stub
		return (List<Customer>) customerDao.findAll();
	}

}
