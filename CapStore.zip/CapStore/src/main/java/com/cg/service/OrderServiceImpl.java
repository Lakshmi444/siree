package com.cg.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.Order;
import com.cg.dao.OrderDao;

@Service

public class OrderServiceImpl implements IOrderService{
	
	@Autowired
	OrderDao orderDao;

	@Override
	public Order createOrder(Order order) {
		// TODO Auto-generated method stub
		
		return orderDao.save(order);
	}

	@Override
	public List<Order> viewOrder() {
		// TODO Auto-generated method stub
		return (List<Order>) orderDao.findAll();
	}

}
