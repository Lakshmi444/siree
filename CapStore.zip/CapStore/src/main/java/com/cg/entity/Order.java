package com.cg.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity(name="Order_Details")

public class Order {
	
	@Id
	private String orderid;
	private String productname;
	private String quantity;
	private String price;
	
	public String getOrderid() {
		return orderid;
	}
	public void setOrderid(String orderid) {
		this.orderid = orderid;
	}
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	
	public Order(String orderid, String productname, String quantity, String price) {
		super();
		this.orderid = orderid;
		this.productname = productname;
		this.quantity = quantity;
		this.price = price;
	}
	
	public Order() {
		super();
	}
	
	@Override
	public String toString() {
		return "Order [orderid=" + orderid + ", productname=" + productname + ", quantity=" + quantity + ", price="
				+ price + "]";
	}
	
}
