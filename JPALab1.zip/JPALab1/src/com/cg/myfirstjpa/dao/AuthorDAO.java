package com.cg.myfirstjpa.dao;

import com.cg.myfirstjpa.entity.Author;

public interface AuthorDAO {

	public  Author getAuthorById(int id);

	public  void addAuthor(Author author);

	public  void removeAuthor(Author author);

	public  void updateAuthor(Author author);


}
