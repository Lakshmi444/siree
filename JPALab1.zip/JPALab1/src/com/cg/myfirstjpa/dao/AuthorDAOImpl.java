package com.cg.myfirstjpa.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.myfirstjpa.entity.Author;

public class AuthorDAOImpl implements AuthorDAO{

	EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em = factory.createEntityManager();	
    @Override
	public Author getAuthorById(int id) {
		Author auhtor = em.find(Author.class, id);
		return auhtor;
	}

	@Override
	public void addAuthor(Author author) {
       em.persist(author);
	}

	@Override
	public void removeAuthor(Author author) {
		em.persist(author);
		
	}

	@Override
	public void updateAuthor(Author author) {
		em.persist(author);
	}

	@Override
	public void commitTransaction() {
		em.getTransaction().commit();
		
	}

	@Override
	public void beginTransaction() {
	em.getTransaction().begin();
		
	}

	@Override
	public void closeFactory() {
	   factory.close();
		
	}

}
