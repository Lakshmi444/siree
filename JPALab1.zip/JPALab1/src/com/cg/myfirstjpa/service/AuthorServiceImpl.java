package com.cg.myfirstjpa.service;

import com.cg.myfirstjpa.dao.AuthorDAO;
import com.cg.myfirstjpa.dao.AuthorDAOImpl;
import com.cg.myfirstjpa.entity.Author;

public class AuthorServiceImpl implements AuthorService{
  AuthorDAO dao = new AuthorDAOImpl();
	@Override
	public Author getAuthorById(int id) {
		return dao.getAuthorById(id);
	}

	@Override
	public void addAuthor(Author author) {
		dao.addAuthor(author);
		
	}

	@Override
	public void removeAuthor(Author author) {
		dao.removeAuthor(author);
		
	}

	@Override
	public void updateAuthor(Author author) {
		dao.removeAuthor(author);
		
	}

	@Override
	public void commitTransaction() {
		dao.commitTransaction();
	}

	@Override
	public void beginTransaction() {
		dao.beginTransaction();
		
	}
	@Override
	public void closeFactory() {
	   dao.closeFactory();
		
	}
}
