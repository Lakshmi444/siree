package com.cg.myfirstjpa.service;

import com.cg.myfirstjpa.entity.Author;

public interface AuthorService {
	
	public  Author getAuthorById(int id);

	public  void addAuthor(Author author);

	public  void removeAuthor(Author author);

	public  void updateAuthor(Author author);

	public  void commitTransaction();

	public  void beginTransaction();
	
	public  void closeFactory();
}
