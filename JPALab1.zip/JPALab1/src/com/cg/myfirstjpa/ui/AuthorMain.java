package com.cg.myfirstjpa.ui;

import java.util.Scanner;

import com.cg.myfirstjpa.entity.Author;
import com.cg.myfirstjpa.service.AuthorService;
import com.cg.myfirstjpa.service.AuthorServiceImpl;

public class AuthorMain {
   static AuthorService service = new AuthorServiceImpl();
   static Scanner sc = new Scanner(System.in);
  
	public static void main(String[] args) {
		while(true)
		{
			System.out.println("What do u want to do??\n");
			System.out.println("1.Add Author \t 2.Delete Author \n");
			System.out.println("3.Update Author \n");
			System.out.println("Enter Your Choice");
			int choice = sc.nextInt();
			switch(choice)
			{
			case 1 :
				addAuthor();
				break;
			case 2 :
				deleteAuthor();
				break;
			case 3 :
				UpdateAuhtor();
				break;
	        default : System.out.println("Choose any Case");
	        	break;
			}
		}
	
	}
	private static void UpdateAuhtor() {
		System.out.println("Enter the Id");
		int id = sc.nextInt();
		service.beginTransaction();
		Author author = service.getAuthorById(id);
		System.out.print("ID:"+author.getAuthorId());
	/*	System.out.println(" FIRSTNAME:"+author.getFirstName());
		System.out.println("MIDDLENAME:"+author.getMiddleName());
		System.out.println("LASTNAME:"+author.getLastName());
		System.out.println("PHONENUMBER:"+author.getPhoneNo());*/

		System.out.println("Enter the first name");
		String fname = sc.next();
		System.out.println("Enter the middle name");
		String mname = sc.next();
		System.out.println("Enter the last name");
		String lname = sc.next();
		System.out.println("Enter the Phone Number");
		String phnno = sc.next();
	    author = new Author(id,fname,mname,lname,phnno);
		service.updateAuthor(author);
		service.closeFactory();
		
	}
	private static void deleteAuthor() {
		System.out.println("Enter the Id");
		int id = sc.nextInt();
		service.beginTransaction();
		Author author = service.getAuthorById(id);
		service.removeAuthor(author);
		service.closeFactory();
	}
	private static void addAuthor() {
		
		
		    System.out.println("Enter the Id ");
			int i=sc.nextInt();
			System.out.println("Enter the first name");
			String fname = sc.next();
			System.out.println("Enter the middle name");
			String mname = sc.next();
			System.out.println("Enter the last name");
			String lname = sc.next();
			System.out.println("Enter the Phone Number");
			String phnno = sc.next();
			Author author = new Author(i,fname,mname,lname,phnno);
			service.beginTransaction();
			service.addAuthor(author);
			service.commitTransaction();
			System.out.println("Added Successfully");
		    service.closeFactory();
	}
	
}
