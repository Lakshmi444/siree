package com.cg.bank.exception;

public class CustomerNameException extends Exception {

	private static final long serialVersionUID = 1L;

	public CustomerNameException(String name) {
		super(name);
		System.out.println("Not Valid");
	}
	
	

}
