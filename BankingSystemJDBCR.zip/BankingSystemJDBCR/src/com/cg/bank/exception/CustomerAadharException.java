package com.cg.bank.exception;

public class CustomerAadharException extends Exception{

	
	private static final long serialVersionUID = 1L;

	public CustomerAadharException(String aadharNo) {
		super(aadharNo);
	  System.out.println("Not Valid");
	}

	
	
}
