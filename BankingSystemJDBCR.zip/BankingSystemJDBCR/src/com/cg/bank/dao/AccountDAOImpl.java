package com.cg.bank.dao;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.util.JDBC;

public class AccountDAOImpl implements AccountDAO{
	JDBC jdbc = new JDBC();

	@Override
	public String createAccount(Customer c, Account acc) {
		Connection con=jdbc.connect();
		Statement stmt=con.createStatement();
		PreparedStatement pst=con.prepareStatement("INSERT INTO ACCOUNT VALUES(?,?)");
		PreparedStatement pst1=con.prepareStatement("INSERT INTO CUSTOMER VALUES(?,?,?,?,?,?,?)");
        pst.setString(2, acc.getAccNumber());
        pst.setDouble(1, acc.getAccbalance());
		pst1.setString(1, c.g);
		pst1.setString(2, c.getCusName());
		pst1.setString(3, c.getCusNumber());
		pst1.setInt(4, c.getCusAge());
		pst1.setString(5, c.getMailId());
		pst1.setString(6, c.getCusAadharNo());
		pst1.setString(7, c.getCity());
		pst1.setInt(8, c.getPinCode());
		pst.executeUpdate();
		pst1.executeUpdate();
		return acc.getAccNumber();
	}

	@Override
	public double showBalance(String accNo) {
		Connection con=jdbc.connect();
		Statement stmt =con.createStatement();
		ResultSet res =stmt.executeQuery("select accbalance from Account where accNumber='"+accNo+"' ");
		double bal = res.getDouble(accbalance);
		return  res;
	}

	@Override
	public double deposit( String accNo,double amount) {
		
		return CollectionUtil.deposit(accNo, amount);
	}

	@Override
	public double withDraw( String accNo,double amount) {
		 
		return CollectionUtil.withDraw(accNo, amount);
	}

	@Override
	public double fundTransfer(String accNo, double amount) {
		
		return CollectionUtil.fundTransfer(accNo,amount);
	}

	@Override
	public Account printTransactions(String accNo) {
		
		return CollectionUtil.printTransactions(accNo);
	}

}
