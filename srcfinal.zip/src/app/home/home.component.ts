import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from '../productservice.service';
import { Products } from './product';
import {Router } from '@angular/router'

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  products:Products[];
 
  constructor(private service : ProductserviceService,private router : Router) { }
  ngOnInit(){
    this.service.getBooks().subscribe(data => this.products=data);
}

fun(){
  this.router.navigate(['/electronic'])
}
fun1(){
  this.router.navigate(['/fashion'])
}
fun2(){
  this.router.navigate(['/laptops'])
}
}
