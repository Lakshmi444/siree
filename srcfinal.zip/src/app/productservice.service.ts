import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Products } from './product';
@Injectable({
  providedIn: 'root'
})
export class ProductserviceService {

  url : string = "http://localhost:8074/getproducts";
  constructor(private http : HttpClient) { }
  getBooks() : Observable<Products []>
{ 
  //let obj : Observable<IBook []> =this.http.get(this.url);
  //return (obj);
  return this.http.get<Products []>(this.url);
}

}


