package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Account;
import com.cg.entity.Customer;
import com.cg.service.AccountService;

@RestController
public class AccountController {

	@Autowired
	AccountService accountService;
	

	@RequestMapping(value = "/bank/add/{cusName}/{cusNumber}/{cusAge}/{mailId}/{cusAadharNo}/{city}/{pinCode}/{accbalance}",
			 method = RequestMethod.GET, headers="Accept=application/json")
	public String createAccount(@PathVariable String cusName,
			@PathVariable String cusNumber,@PathVariable int cusAge,@PathVariable String mailId,@PathVariable String cusAadharNo,@PathVariable String city,@PathVariable int pinCode,@PathVariable double accbalance) {
		Account account=new Account();
		Customer customer = new Customer();
		customer.setCusName(cusName);
		customer.setCusNumber(cusNumber);
		customer.setCusAge(cusAge);
		customer.setMailId(mailId);
		customer.setCusAadharNo(cusAadharNo);
		customer.setCity(city);
		customer.setPinCode(pinCode);
		customer.setAccNo(account.getAccNumber());
		account.setAccbalance(accbalance);
		int accNumber= accountService.createAccount(customer, account);
		
	    return "Account Successfully Created"+accNumber;
		
	}
	
	@RequestMapping(value = "/bank/show/{accNumber}",method=RequestMethod.GET,headers="Accept=application/json")
	public String showBalance(@PathVariable int accNumber) {
		 double balance=accountService.showBalance(accNumber);
		return "Your Balance is :"+balance;
	}
	@RequestMapping(value = "/bank/deposit/{accNumber}/{amount}",method=RequestMethod.GET,headers="Accept=application/json")
	public String deposit(@PathVariable int accNumber,@PathVariable double amount) {
		double balance=accountService.deposit(accNumber, amount);
		return "Deposited Successfully\n Total Balance : "+balance;
	}
	@RequestMapping(value = "/bank/withdraw/{accNumber}/{amount}",method=RequestMethod.GET,headers="Accept=application/json")
public String withdraw(@PathVariable int accNumber,@PathVariable double amount) {
		double balance=accountService.withDraw(accNumber, amount);
		return "Withdrawn Successfully \n Remaining Balance :"+balance;
	}
	@RequestMapping(value = "/bank/fundtransfer/{accNumber}/{accNumber2}/{amount}",method=RequestMethod.GET,headers="Accept=application/json")
	public String fundtransfer(@PathVariable int accNumber,@PathVariable int accNumber2,@PathVariable int amount) {
		double bal =accountService.fundTransfer(accNumber, amount);
		return "Transferred Successfully \n Remaining Balance"+bal;
	}
	
	@RequestMapping(value = "/bank/print/{accNumber}",method=RequestMethod.GET,headers="Accept=application/json")
	public String printTransacations(@PathVariable int accNumber) {
		 Account acc=accountService.printTransactions(accNumber);
		return "Account Details"+acc;
	}
}
