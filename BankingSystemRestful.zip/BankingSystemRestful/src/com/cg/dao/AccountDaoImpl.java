package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entity.Account;
import com.cg.entity.Customer;

@Repository
public class AccountDaoImpl implements AccountDao {

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public int createAccount(Customer c, Account acc) {
		entityManager.persist(c);
		entityManager.persist(acc);
		//entityManager.flush();
		return acc.getAccNumber();
	}

	@Override
	public double showBalance(int accNo) {
		Account  acc= entityManager.find(Account.class, accNo);
		if(acc!=null)
		{
			
		return acc.getAccbalance();
		}
		else {
			
			return 0.0;
		}	
		
	}

	@Override
	public double deposit(int accNo, double amount) {
		
		Account  acc= entityManager.find(Account.class, accNo);
		String str="SELECT acc.accbalance FROM Account acc WHERE acc.accNumber=:num";
		TypedQuery<Double> query=entityManager.createQuery(str,Double.class);
		query.setParameter("num",accNo);
		Double e=query.getSingleResult();
		Double balance = e+amount;
		acc.setAccbalance(balance);
	
        return balance;
	}

	@Override
	public double withDraw(int accNo, double amount) {
	
		Account  acc= entityManager.find(Account.class, accNo);
		String str="SELECT acc.accbalance FROM Account acc WHERE acc.accNumber=:num";
		TypedQuery<Double> query=entityManager.createQuery(str,Double.class);
		query.setParameter("num",accNo);
		Double e=query.getSingleResult();
		double balance = e-amount;
		acc.setAccbalance(balance);
	
		return balance;
	}

	@Override
	public double fundTransfer(int accNo, double amount) {
		 
		  Account  acc= entityManager.find(Account.class, accNo);
		  String str="SELECT acc.accbalance FROM Account acc WHERE acc.accNumber=:num";
		  TypedQuery<Double> query=entityManager.createQuery(str,Double.class);
		  query.setParameter("num",accNo);
		  Double e=query.getSingleResult();
		  double balance = e-amount;
		  acc.setAccbalance(balance);
		
         return balance;
	}

	@Override
	public Account printTransactions(int accNo) {
		
			
			  Account  acc= entityManager.find(Account.class, accNo);
			//  Customer c = em.find(Customer.class, accNo);

		      return acc;
	}

}
