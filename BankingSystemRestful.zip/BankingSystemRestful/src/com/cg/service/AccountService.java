package com.cg.service;

import com.cg.entity.Account;
import com.cg.entity.Customer;

public interface AccountService {

	public int createAccount(Customer c,Account acc);
	public double showBalance(int accNo);
	public double deposit(int accNo,double amount);
	public double withDraw(int accNo,double amount);
	public double fundTransfer(int accNo,int accNo1,double amount);
	public Account printTransactions(int accNo);
	
}
