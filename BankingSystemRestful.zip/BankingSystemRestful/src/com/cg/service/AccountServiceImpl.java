package com.cg.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.AccountDao;
import com.cg.entity.Account;
import com.cg.entity.Customer;

@Service
@Transactional
public class AccountServiceImpl implements AccountService {

	@Autowired
	AccountDao accountDao;
	
	@Override
	public int createAccount(Customer c, Account acc) {
		// TODO Auto-generated method stub
		return accountDao.createAccount(c, acc);
	}

	@Override
	public double showBalance(int accNo) {
		// TODO Auto-generated method stub
		return accountDao.showBalance(accNo);
	}

	@Override
	public double deposit(int accNo, double amount) {
		// TODO Auto-generated method stub
		return accountDao.deposit(accNo, amount);
	}

	@Override
	public double withDraw(int accNo, double amount) {
		// TODO Auto-generated method stub
		return accountDao.withDraw(accNo, amount);
	}

	@Override
	public double fundTransfer(int accNo,int accNo1, double amount) {
		// TODO Auto-generated method stub
		return accountDao.fundTransfer(accNo,accNo1, amount);
	}

	@Override
	public Account printTransactions(int accNo) {
		// TODO Auto-generated method stub
		return accountDao.printTransactions(accNo);
	}

}
