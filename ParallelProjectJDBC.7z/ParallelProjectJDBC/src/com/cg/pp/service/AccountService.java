package com.cg.pp.service;

import java.sql.SQLException;
import com.cg.pp.entity.Account;
import com.cg.pp.entity.Customer;
public interface AccountService {

	boolean validateCustomerName(String cusName);
	boolean validateCustomerNumber(String cusNo);
	boolean validateCustomerMailId(String mailId);
	boolean validateCustomerAadharNo(String aadharNo);
	public void createaccount(Account acc, Customer c) throws ClassNotFoundException, SQLException;
	public Account showbalance(String a) throws ClassNotFoundException, SQLException;
	public Account deposit(double updatedAmt, String s) throws ClassNotFoundException, SQLException;
	
	
	




}
