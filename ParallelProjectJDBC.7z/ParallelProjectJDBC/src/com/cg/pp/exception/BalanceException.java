package com.cg.pp.exception;

public class BalanceException extends Exception {

	public BalanceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
