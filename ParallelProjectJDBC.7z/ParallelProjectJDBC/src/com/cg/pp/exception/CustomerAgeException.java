package com.cg.pp.exception;

public class CustomerAgeException extends Exception {

	public CustomerAgeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
