package com.cg.pp.exception;

public class CustomerNumberException extends Exception {

	public CustomerNumberException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
