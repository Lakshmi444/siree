package com.cg.pp.dao;

import java.sql.SQLException;
import java.util.HashMap;
import com.cg.pp.entity.Account;
import com.cg.pp.entity.Customer;
public interface AccountDAO {

	public void createaccount(Account a,Customer b) throws SQLException, ClassNotFoundException;
	public Account deposit(double amt,String acc) throws ClassNotFoundException, SQLException;
	public void withdraw(double res, int acc) throws ClassNotFoundException, SQLException;
	public Account showbalance(String accNumber) throws ClassNotFoundException, SQLException;
}