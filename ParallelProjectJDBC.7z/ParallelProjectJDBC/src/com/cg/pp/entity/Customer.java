package com.cg.pp.entity;

public class Customer {
	private String cusName;
	private String cusNumber;
	private int cusAge;
	private String mailId;
	private String cusAadharNo;
	private String city;
	private int pinCode;

	public Customer()
	{
		super();
	}
	public Customer(String cusName, String cusNumber, int cusAge, String mailId, String cusAadharNo, String city,
			int pinCode) {
		super();
		this.cusName = cusName;
		this.cusNumber = cusNumber;
		this.cusAge = cusAge;
		this.mailId = mailId;
		this.cusAadharNo = cusAadharNo;
		this.city = city;
		this.pinCode = pinCode;
		
	}
	public String getCusName() {
		return cusName;
	}
	public void setCusName(String cusName) {
		this.cusName = cusName;
	}
	public String getCusNumber() {
		return cusNumber;
	}
	public void setCusNumber(String cusNumber) {
		this.cusNumber = cusNumber;
	}
	public int getCusAge() {
		return cusAge;
	}
	public void setCusAge(int cusAge) {
		this.cusAge = cusAge;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public String getCusAadharNo() {
		return cusAadharNo;
	}
	public void setCusAadharNo(String cusAadharNo) {
		this.cusAadharNo = cusAadharNo;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getPinCode() {
		return pinCode;
	}
	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}
	
	@Override
	public String toString() {
		return "Customer [cusName=" + cusName + ", cusNumber=" + cusNumber + ", cusAge=" + cusAge + ", mailId=" + mailId
				+ ", cusAadharNo=" + cusAadharNo + ", city=" + city + ", pinCode=" + pinCode +  "]";
	}
	
}

	
	
