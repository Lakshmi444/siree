package com.cg.pp.entity;

public class Account {
	
		private   String bankName;
		private  String branch;
		private  String ifscCode;
		private String accNumber ;
	    private double accbalance;
		public Account()
		{
			super();
		}
		public Account(String bankName, String branch, String ifscCode, String accNumber, double accbalance) {
			super();
			this.bankName = bankName;
			this.branch = branch;
			this.ifscCode = ifscCode;
			this.accNumber = accNumber;
			this.accbalance = accbalance;
		}
		@Override
		public String toString() {
			return "Account [bankName=" + bankName + ", branch=" + branch + ", ifscCode=" + ifscCode + ", accNumber="
					+ accNumber + ", accbalance=" + accbalance + "]";
		}
		public String getBankName() {
			return bankName;
		}
		public void setBankName(String bankName) {
			this.bankName = bankName;
		}
		public String getBranch() {
			return branch;
		}
		public void setBranch(String branch) {
			this.branch = branch;
		}
		public String getIfscCode() {
			return ifscCode;
		}
		public void setIfscCode(String ifscCode) {
			this.ifscCode = ifscCode;
		}
		public String getAccNumber() {
			return accNumber;
		}
		public void setAccNumber(String accNumber) {
			this.accNumber = accNumber;
		}
		public double getAccbalance() {
			return accbalance;
		}
		public void setAccbalance(double accbalance) {
			this.accbalance = accbalance;
		}
	
		

		
	}

