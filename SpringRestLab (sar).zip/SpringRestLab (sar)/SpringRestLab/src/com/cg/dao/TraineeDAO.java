package com.cg.dao;

import java.util.List;

import com.cg.entity.Trainee;

public interface TraineeDAO {

	public void add(Trainee trainee);
	public Trainee find(int traineeId);
	public Trainee delete(Trainee trainee);
	public List<Trainee> retrieveAll();
	public Trainee update(Trainee trainee,int traineeId);
}
