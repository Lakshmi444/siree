package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.TraineeDAO;
import com.cg.entity.Trainee;

@Service
@Transactional
public class TraineeServiceImpl implements TraineeService {

	@Autowired
	TraineeDAO traineeDao;
	
	@Override
	public void add(Trainee trainee) {
		traineeDao.add(trainee);

	}

	@Override
	public Trainee find(int traineeId) {
		
		return traineeDao.find(traineeId);
	}

	@Override
	public Trainee delete(Trainee trainee) {
		
		return traineeDao.delete(trainee);
	}

	@Override
	public List<Trainee> retrieveAll() {
		
		return traineeDao.retrieveAll();
	}

	@Override
	public Trainee update(Trainee trainee,int traineeId) {
		
		return traineeDao.update(trainee,traineeId);
	}

}
