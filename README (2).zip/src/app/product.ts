export interface IProduct
{
    product_id:number;
	
	product_name:string;
	
 product_quantity:number;
	
	 product_price : number;
	
 product_description:string;
	
	 product_rating:number;
	
	 category_name:string;
	
	product_brand:string;
	
	 product_discount:string;
	
	 merchant_id:number;
	
	 image:string;


}