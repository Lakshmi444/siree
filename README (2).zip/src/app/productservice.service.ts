import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IProduct } from './product';
@Injectable({
  providedIn: 'root'
})
export class ProductserviceService {

  url : string = "http://localhost:8077/getproducts";
  constructor(private http : HttpClient) { }
  getBooks() : Observable<IProduct []>
{ 
  //let obj : Observable<IBook []> =this.http.get(this.url);
  //return (obj);
  return this.http.get<IProduct []>(this.url);
}
}


