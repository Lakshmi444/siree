import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from './productservice.service';
import { IProduct } from './product';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  products:IProduct[];

  constructor(private service : ProductserviceService) { }
  ngOnInit(){
    this.service.getBooks().subscribe(data => this.products=data);
 alert(this.products)
  }

 
}
