package com.cg.pp.dao;

import com.cg.pp.entity.Account;
import com.cg.pp.entity.Customer;

public interface AccountDAO {
	
	public String createAccount(Customer c,Account acc);
	public double showBalance(String accNo);
	public double deposit(String accNo,double amount);
	public double withDraw(String accNo,double amount);
	public double fundTransfer(String accNo,double amount);
	public Account printTransactions(String accNo);

}

