package com.cg.pp.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.pp.entity.Account;
import com.cg.pp.entity.Customer;

public class CollectionUtil{
	private static Map<String,Account> accMap = new HashMap<String,Account>();
	private static Map<String,Customer> cusMap = new HashMap<String,Customer>(); 
	static
	{
		cusMap.put("945958742365", new Customer("Sarah","9490150279",25,"Sarah02@gmail.com","432504659687","Eluru",521214));
		cusMap.put("894595874236", new Customer("Samuel","9866696047",27,"Samuel16@gmail.com","432504659687","Hyderabad",521245));
		cusMap.put("785958742365", new Customer("Jenifer","9491458096",23,"Jenifer18@gmail.com","432504659687","Eluru",512243));
		cusMap.put("567558742365", new Customer("Jancy","9492810110",29,"Jancy20@gmail.com","432504659687","Eluru",543214));
		cusMap.put("675958742365", new Customer("David","9490745409",30,"David22@gmail.com","432504659687","Eluru",532145));
		accMap.put("945958742365",new Account("945958742365",63000.0) );
		accMap.put("894595874236",new Account("894595874236",44526.0) );
		accMap.put("785958742365",new Account("785958742365",53632.0) );
		accMap.put("567558742365",new Account("567558742365",73250.0) );
		accMap.put("675958742365",new Account("675958742365",24677.0) );
	}
	
	public static void createAccount(Customer c, Account acc) {
		cusMap.put(acc.getAccNumber(), c);
		accMap.put(acc.getAccNumber(), acc);
	}
	public static double showBalance(String accNo) {
		if(accMap.containsKey(accNo))
		{
		Account acc= accMap.get(accNo);
		return acc.getAccbalance();
		}
		return 0;
	}
	public static double deposit( String accNo,double amount) {
			Account acc = accMap.get(accNo);
			double balance = acc.getAccbalance()+amount;
			accMap.put(acc.getAccNumber(),new Account(acc.getAccNumber(),balance) );
			return balance;
	
	}
	public static double withDraw(String accNo,double amount ) {
        	Account acc = accMap.get(accNo);
			double balance = acc.getAccbalance()-amount;
			accMap.put(acc.getAccNumber(),new Account(acc.getAccNumber(),balance) );
			return balance;
		
    }
	public static double fundTransfer(String accNo,double amount)
	{
		       Account acc = accMap.get(accNo);
		
		       double balance = acc.getAccbalance()-amount;
				accMap.put(acc.getAccNumber(),new Account(acc.getAccNumber(),balance));
				return balance;
			
		
	}
	public static Account printTransactions(String accNo)
	{
		if(accMap.containsKey(accNo))
		{
		  Account acc =accMap.get(accNo);
		  return acc;
		}
		return null;
		
	}
	
}
	


	
	

