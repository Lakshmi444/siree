package com.cg.pp.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.pp.dao.AccountDAO;
import com.cg.pp.dao.AccountDAOIMPl;
import com.cg.pp.entity.Account;
import com.cg.pp.entity.Customer;

public class AccountServiceImpl implements AccountService {
    AccountDAO accDAO = new AccountDAOIMPl();
	@Override
	public String createAccount(Customer c, Account acc) {
		accDAO.createAccount(c, acc);
		return acc.getAccNumber();
	}

	@Override
	public double showBalance(String accNo) {
	
		return	accDAO.showBalance(accNo);
	}

	@Override
	public double deposit(String accNo,double amount) {
		
		return accDAO.deposit(accNo, amount);
	}

	@Override
	public double withDraw(String accNo,double amount) {
	
		return 	accDAO.withDraw(accNo,amount);
	}

	@Override
	public boolean validateCustomerName(String name) {
		Pattern pattern = Pattern.compile("^[A-Z]{1}[a-z]{2,}");
		Matcher custnameMatch = pattern.matcher(name);
		if(custnameMatch.matches())
		{
			return true;
		}
		return false;
	}

	@Override
	public boolean validateCustomerNumber(String number) {
		Pattern pattern = Pattern.compile("[0-9]{10}");
		Matcher custnumMatch = pattern.matcher(number);
		if(custnumMatch.matches())
		{
			return true;
		}
		return false;
	}
	@Override
	public boolean validateCustomerMailId(String mailId) {
		Pattern pattern = Pattern.compile("^[A-Za-z0-9+._-]+@[a-z](.+)[a-z]$");
		Matcher custgmailMatch = pattern.matcher(mailId);
		if(custgmailMatch.matches())
		{
			return true;
		}
		return false;
	}

	@Override
	public boolean validateCustomerAadharNo(String cusAadharNo) {
		Pattern pattern = Pattern.compile("[0-9]{12}");
		Matcher custnumMatch = pattern.matcher(cusAadharNo);
		if(custnumMatch.matches())
		{
			return true;
		}
		return false;
	}

	@Override
	public double fundTransfer(String accNo, double amount) {
		
		return accDAO.fundTransfer(accNo, amount);
	}

	@Override
	public Account printTransactions(String accNo) {
		return accDAO.printTransactions(accNo);
	}

}
