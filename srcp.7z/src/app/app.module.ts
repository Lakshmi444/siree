import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { Route,RouterModule } from '@angular/router';
import {HttpClientModule} from '@angular/common/http';
import { AppComponent } from './app.component';
import { ElectronicdevicesComponent } from './electronicdevices/electronicdevices.component';
import { FashionComponent } from './fashion/fashion.component';
import { ClothingComponent } from './clothing/clothing.component';
import { BooksComponent } from './books/books.component';
const routes :Route[]=[
  {
    path: 'electronic',
    component:ElectronicdevicesComponent
  },
  {
    path: 'book',
    component:BooksComponent
  },
  {
    path: 'cloth',
    component:ClothingComponent
  },
  {
    path: 'fashion',
    component:FashionComponent
  }]
@NgModule({
  declarations: [
    AppComponent,
    ElectronicdevicesComponent,
    FashionComponent,
    ClothingComponent,
    BooksComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
