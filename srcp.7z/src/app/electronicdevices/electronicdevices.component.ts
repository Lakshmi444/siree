import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-electronicdevices',
  templateUrl: './electronicdevices.component.html',
  styleUrls: ['./electronicdevices.component.css']
})
export class ElectronicdevicesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
