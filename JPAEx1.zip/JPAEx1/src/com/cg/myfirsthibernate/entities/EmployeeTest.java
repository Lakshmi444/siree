package com.cg.myfirsthibernate.entities;

public class EmployeeTest {
public static void main(String[] args) {
		
		
	}
}
