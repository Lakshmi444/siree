package com.cg.myfirsthibernate.entities;
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;


@Entity
@Table(name="Emp_Details")
public class Employee  implements Serializable{

	private static final long serialVersionUID = 1L;
	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="myseq")
	@SequenceGenerator(name="myseq", sequenceName="empid_seq")
	
	//@Column(name="Emp_Id")
	private int Emp_Id;
	//@Column(name="Emp_Name")
	private String Emp_Name;
	@Transient
	//@Column(name="Emp_Salary")
	private int Emp_Salary;
	
	public int getStudentId() {
		return Emp_Id;
	}
	public void setStudentId(int Emp_Id) {
		this.Emp_Id = Emp_Id;
	}
	public String getName() {
		return Emp_Name;
	}
	public void setName(String Emp_Name) {
		this.Emp_Name =Emp_Name;
	}
    public int getSalary()
    {
    	return Emp_Salary;
    }
    public void setSalary(int Emp_Salary)
    {
    	this.Emp_Salary=Emp_Salary;
    }
}
