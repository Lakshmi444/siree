package com.cg.myfirsthibernate.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.myfirsthibernate.entities.Employee;
import com.cg.myfirsthibernate.service.MyJPAService;
import com.cg.myfirsthibernate.service.MyJPAServiceImpl;

public class Test {
	static EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
	static EntityManager em = factory.createEntityManager();
	static MyJPAService service;
public static void main(String[] args) {
	service= new MyJPAServiceImpl();
	Employee emp= new Employee();
	emp.setName("Lakshmi");
	emp.setSalary(40000);
	em.getTransaction().begin();
	service.addEmployee(emp);
	//service.removeEmployee(emp);
//	service.updateEmployee(emp);
	//System.out.println("Added one Employee to database.");
	
	//service.deleteEmployee(emp);
	em.getTransaction().commit();
	em.close();
	factory.close();
	
}
}
