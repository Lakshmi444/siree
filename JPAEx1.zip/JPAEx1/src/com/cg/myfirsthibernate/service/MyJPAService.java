package com.cg.myfirsthibernate.service;

import com.cg.myfirsthibernate.entities.Employee;

public interface MyJPAService {
	public void addEmployee(Employee emp);
	public void deleteEmployee(Employee emp);
    public void removeEmployee(Employee emp);
    public void updateEmployee(Employee emp);
}
