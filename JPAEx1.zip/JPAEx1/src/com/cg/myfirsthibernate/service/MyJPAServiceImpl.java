package com.cg.myfirsthibernate.service;

import com.cg.myfirsthibernate.dao.MyJPADAO;
import com.cg.myfirsthibernate.dao.MyJPADAOImpl;
import com.cg.myfirsthibernate.entities.Employee;

public class MyJPAServiceImpl implements MyJPAService {
  MyJPADAO dao=new MyJPADAOImpl() ;
	
	@Override
	public void deleteEmployee(Employee emp) {
		dao.deleteEmployee(emp);
		
	}
	
	@Override
	public void addEmployee(Employee emp) {
		dao.addEmployee(emp);
		
	}

	@Override
	public void removeEmployee(Employee emp) {
		dao.removeEmployee(emp);
	}

	@Override
	public void updateEmployee(Employee emp) {
		dao.updateEmployee(emp);
	}

}


