package com.cg.myfirsthibernate.dao;

import com.cg.myfirsthibernate.entities.Employee;

public interface MyJPADAO {

	public void addEmployee(Employee emp);
	public void deleteEmployee(Employee emp);
    public void removeEmployee(Employee emp);
    public void updateEmployee(Employee emp);

}
