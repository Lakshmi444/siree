package com.cg.myfirsthibernate.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.myfirsthibernate.entities.Employee;

public class MyJPADAOImpl implements MyJPADAO{
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em = factory.createEntityManager();
	@Override
	public void addEmployee(Employee emp) {
		System.out.println("Calling Add Employee");
		em.getTransaction().begin();
		em.persist(emp);
		System.out.println("Added one Employee to database.");
		  em.getTransaction().commit();
		   factory.close();
		
	}
	@Override
	public void deleteEmployee(Employee emp) {
		System.out.println("Calling Delete Employee");
		
		//em.persist(emp);
		//System.out.println("Deleted one Employee from database.");
	 
	}

	@Override
	public void removeEmployee(Employee emp) {
	//	em.remove(emp);
	}

	@Override
	public void updateEmployee(Employee emp) {
		em.merge(emp);
	}


}
