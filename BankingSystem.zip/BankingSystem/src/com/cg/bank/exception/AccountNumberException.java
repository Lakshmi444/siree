package com.cg.bank.exception;

public class AccountNumberException extends Exception{




	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AccountNumberException(String accNo) {
		super(accNo);
	System.out.println("Given Account not exists");
	}

	
}
