package com.cg.bank.exception;

public class CustomerNumberException extends Exception{

	private static final long serialVersionUID = 1L;

	public CustomerNumberException(String number) {
		super(number);
		System.out.println("Not Valid");
	}

	
	
}
