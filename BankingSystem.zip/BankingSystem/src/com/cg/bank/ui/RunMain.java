package com.cg.bank.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.exception.AccountNumberException;
import com.cg.bank.exception.BalanceException;
import com.cg.bank.exception.CustomerAadharException;
import com.cg.bank.exception.CustomerAgeException;
import com.cg.bank.exception.CustomerMailIdException;
import com.cg.bank.exception.CustomerNameException;
import com.cg.bank.exception.CustomerNumberException;
import com.cg.bank.service.AccountService;
import com.cg.bank.service.AccountServiceImpl;

public class RunMain {

	static Scanner sc = null;
	static AccountService accService = null;
	static Account acc ;
	static Customer c ;
	public static void main(String[] args) throws AccountNumberException, BalanceException  {
		 sc = new Scanner(System.in);
		 accService = new AccountServiceImpl();
		 int choice;
		while(true)
		{
		 System.out.println("\n What U Want To DO?");
		 System.out.println("1.Create Account\t 2.Show Balance\n");
		 System.out.println("3.Deposit\t 4.WithDraw\n");
		 System.out.println("5.Fund Transfer\t 6.Print Transactions\n");
		 System.out.println("7.Exit");
		 System.out.println("Enter Your Choice");
	
		 choice=sc.nextInt();
		 switch(choice)
		 {
		 case 1:
			 createAccount();
			 break;
		 case 2:
			 showBalance();
			 break;
		 case 3:
			 deposit();
			 break;
		 case 4:
			 withDraw();
			 break;
		 case 5:
			 fundTransfer();
			 break;
		 case 6:
			 printTransactions();
			 break;
		 case 7:
			 System.exit(0);
		default:
				System.out.println("Select any Case");	 
				break;
		 }
	
	}
	}
	public static void printTransactions() {
		System.out.println("Enter the Account Number");
		String accNo = sc.next();
	
		try
		{
		     acc = accService.printTransactions(accNo);
			if(acc!=null)
			{
			System.out.println("Account Details  ");
			System.out.println("Bank Name  :"+acc.getBankName()+"\nBank Branch : "+acc.getBranch()+" \nBank IFSC Code : "+acc.getIfscCode()+" \nAccount Number  : "+acc.getAccNumber()+" \nAccount Balance : "+acc.getAccbalance()+" \n Date :"+LocalDate.now());
		  }
		else
		{
			throw new AccountNumberException(accNo);
		}
		}
		catch(Exception e)
		{
			
		}
	}
	public static void fundTransfer() throws BalanceException {
		System.out.println("Enter the Account Number ");
		String accNo = sc.next();
		System.out.println("Enter the amount to transfer");
		double amount = sc.nextDouble();
		double balance = accService.showBalance(accNo);
		try
		{
		if(balance!=0)
		{
	    try
	    {
		
		if(amount<balance)
		{
			System.out.println("Enter the Account Number to which account to transfer");
			String accNo1 = sc.next();
			double balance1 = accService.showBalance(accNo1);
			double remainingAmount=0;
			try
			{
			if(balance1!=0)
			{
				 remainingAmount=accService.fundTransfer(accNo, amount);
				System.out.println("Successfully Transferred");
			
			System.out.println("Print Transactions\n");
			System.out.println("1.Yes \t 2.No");
			System.out.println("Enter Your Choice");
			int ch = sc.nextInt();
			switch(ch)
			{
			case 1:
				System.out.println("Bank Name : " +acc.getBankName()+"\n Branch :"+acc.getBranch()+" \n IFSC Code "+acc.getIfscCode());
				System.out.println("Balance in the Account before transfer "+balance);
				System.out.println("Remaining Balance in the Account after transaction "+remainingAmount);
				break;
			case 2:
				System.exit(0);
				break;
				default:
					System.out.println("Select Any One");
					break;
			}
			
		}
		else
		{
			throw new AccountNumberException(accNo1);
			
		}
	    }
	    
		catch(Exception ee)
		{
			
		}
		}
		else
		{
			String bal =String.valueOf(amount);
			throw new BalanceException(bal);
		}
		}
		catch(Exception ex)
		{
			
		}
		}
		else
		{
			throw new AccountNumberException(accNo);
		}
		}
		catch(Exception e)
		{
			
		}
		
	}
	public static void createAccount() {
	while(true)
	{
	 System.out.println("Enter Customer Name");
	 String cusName=sc.next();
	 try
	 {
	 if(accService.validateCustomerName(cusName))
	 {
		
		 System.out.println("Enter Customer Mobile Number");
		 String cusNo = sc.next();
		 try
		 {
		 if(accService.validateCustomerNumber(cusNo))
		 {
			 System.out.println("Enter Customer Age");
			 int age = sc.nextInt();
			 if(age>18)
			 {
				 System.out.println("Enter Customer gmail Id");
				 String mailId=sc.next();
				 try
				 {
				 if(accService.validateCustomerMailId(mailId))
				 {
					 System.out.println("Enter Customer Aadhar Number");
					 String aadharNo = sc.next();
					 if(accService.validateCustomerAadharNo(aadharNo))
					 {
						 System.out.println("Enter Customer City");
						 String city = sc.next();
						 System.out.println("Enter Customer Pincode");
						 int pinCode= sc.nextInt();
					    Customer c = new Customer(cusName,cusNo,age,mailId,aadharNo,city,pinCode);
					    int max= 999999999;
					    int min = 0;
					    int range = (max-min);
					    int accNo = (int)(Math.random()*range);
					    String accNumber = String.valueOf(accNo);
					    System.out.println("Enter initial amount to deposit");
					    double amount = sc.nextDouble();
					    Account acc=new Account(accNumber,amount);
                        accService.createAccount(c, acc);
                        System.out.println("Your Account Successfully Created  "+accNumber+ "\n Bank Name : "+acc.getBankName()+"\n Branch Name :"+acc.getBranch()+" \n IFSC Code "+acc.getIfscCode()+" \n Account Balance :"+acc.getAccbalance());
					 }
					 else
					 {
						 throw new CustomerAadharException(aadharNo);
					 }
				 }
				 else
				 {
					 throw new CustomerMailIdException(mailId);
				 }
				 }
				 catch(Exception e)
				 {
					 
				 }
			 }
			 else
			 {
				 String age1 = String.valueOf(age);
				 throw new CustomerAgeException(age1);
			 }
		 }
		 else
		 {
			 throw new CustomerNumberException(cusNo);
		 }
		 }
		 catch(Exception ex)
		 {
			
		 }
	 }
	 else
	 {
		 throw new CustomerNameException(cusName);
		 
	 }
	 }
    catch(Exception exc)
	 {
		
	 }
	 break;
	}
		
	}
	public static void showBalance() throws AccountNumberException {
		System.out.println("Enter Account Number");
		String accNo = sc.next();
		
		double balance =accService.showBalance(accNo);
		try
		{
		if(balance!=0)
		{
		System.out.println("Balance in the Account is");
		System.out.println(balance);
		}
		else
		{
		throw new AccountNumberException(accNo);	
		}
		}
		catch(Exception e)
		{
			
		}
	}
	public static void deposit() throws AccountNumberException {
	System.out.println("Enter Account Number");
	String accNo = sc.next();
	System.out.println("Enter Amount");
	double amount = sc.nextDouble();
	double actualAmount = accService.showBalance(accNo);
	
	try
	{
	if(actualAmount!=0)
	{
	double balance = accService.deposit(accNo, amount);
	System.out.println("Successfully Deposited");
	System.out.println("Print Transactions\n");
	System.out.println("1.Yes \t 2.No");
	System.out.println("Enter Your Choice");
	int ch = sc.nextInt();
	switch(ch)
	{
	case 1:
		System.out.println("Balance in the Account before Deposit "+actualAmount);
		System.out.println("Remaining Balance in the Account after Deposited "+balance);
		break;
	case 2:
		System.exit(0);
		break;
		default:
			System.out.println("Select Any One");
			break;
	}
	}
	else
	{
		throw new AccountNumberException(accNo);	
	}
	}
	catch(Exception e)
	{
		
	}
	}
	public static void withDraw() throws BalanceException {
		System.out.println("Enter the Account Number");
		String  accNo = sc.next();
		
		System.out.println("Enter the amount");
		double amount = sc.nextDouble();
		double accBalance = accService.showBalance(accNo);
		try
		{
		if(accBalance!=0)
		{
			try
			{
			if(amount<accBalance)
			{
			double remainingBalance = accService.withDraw(accNo, amount);
		    System.out.println("Successfully Withdrawn");
		   
		     System.out.println("Print Transactions\n");
		 	System.out.println("1.Yes \t 2.No \n");
		 	System.out.println("Enter Your Choice");
		 	int ch = sc.nextInt();
		 	switch(ch)
		 	{
		 	case 1:
		 		System.out.println("Balance in the Account before withdrawl "+accBalance);
		 		System.out.println("Remaining Balance in the Account after WithDrawl "+remainingBalance);
		 		break;
		 	case 2:
		 		System.exit(0);
		 		break;
		 		default:
		 			System.out.println("Select Any One");
		 			break;
		 	}
			}
			else
			{
				String bal = String.valueOf(amount);
				throw new BalanceException(bal);
			}
			}
			catch(Exception ee)
			{
				
			}
		}
		else
		{
			String amount1 = String.valueOf(amount);
			throw new AccountNumberException(amount1);
		}
		}
		catch(Exception e)
		{
			
		}
	}
	
}
