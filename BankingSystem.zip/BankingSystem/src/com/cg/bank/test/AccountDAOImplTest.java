package com.cg.bank.test;



import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;

import com.cg.bank.dao.AccountDAO;
import com.cg.bank.dao.AccountDAOImpl;
import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.exception.CustomerAadharException;
import com.cg.bank.exception.CustomerAgeException;
import com.cg.bank.exception.CustomerMailIdException;
import com.cg.bank.exception.CustomerNameException;
import com.cg.bank.exception.CustomerNumberException;

class AccountDAOImplTest {
	/*@Test
	void test() {
		fail("Not yet implemented");
	}*/
	static AccountDAO accDAO; 
	@BeforeClass
		public static void setUp()
		{
		accDAO=new AccountDAOImpl();
		} 
	@Test
		public void createAccountTest() throws CustomerNameException,CustomerNumberException,CustomerAgeException,CustomerMailIdException,CustomerAadharException
		{
		Customer c = new Customer("Mounika","9874563215",25,"mounika@gmail.com","456321789654","Vijayawada",523002);
		Account acc = new Account("983429112",3354.0);
		accDAO.createAccount(c,acc);
		 
		Assert.assertEquals("983429112",acc.getAccNumber());
		
		} 

}
