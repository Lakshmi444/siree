package com.cg.bank.dao;



import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.util.CollectionUtil;

public class AccountDAOImpl implements AccountDAO{

	@Override
	public String createAccount(Customer c, Account acc) {
		CollectionUtil.createAccount(c, acc);
		return acc.getAccNumber();
	}

	@Override
	public double showBalance(String accNo) {
		
		return CollectionUtil.showBalance(accNo);
	}

	@Override
	public double deposit( String accNo,double amount) {
		
		return CollectionUtil.deposit(accNo, amount);
	}

	@Override
	public double withDraw( String accNo,double amount) {
		 
		return CollectionUtil.withDraw(accNo, amount);
	}

	@Override
	public double fundTransfer(String accNo, double amount) {
		
		return CollectionUtil.fundTransfer(accNo,amount);
	}

	@Override
	public Account printTransactions(String accNo) {
		
		return CollectionUtil.printTransactions(accNo);
	}

}
