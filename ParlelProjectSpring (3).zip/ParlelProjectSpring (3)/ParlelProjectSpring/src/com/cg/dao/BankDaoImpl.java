package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.entity.Bank;

@Repository
public class BankDaoImpl implements BankDao{
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public void createAccount(Bank bank) {
		// TODO Auto-generated method stub
		entityManager.persist(bank);
		entityManager.flush();
		
	}

	@Override
	public Bank showBalance(int accNumber) {
		// TODO Auto-generated method stub
		return entityManager.find(Bank.class,accNumber);
	}

	@Override
	public Bank deposite(int accNumber, int amount) {
		// TODO Auto-generated method stub
		Bank bank=entityManager.find(Bank.class,accNumber);
		int bal=bank.getBalance();
		int amount1=bal+amount;
		bank.setBalance(amount1);
		entityManager.merge(bank);
		
		return bank;
	}

	@Override
	public Bank withdraw(int accNumber, int amount) {
		// TODO Auto-generated method stub
		Bank bank=entityManager.find(Bank.class,accNumber);
		int bal=bank.getBalance();
		if(bal>amount) {
			int amount1=bal-amount;
			bank.setBalance(amount1);
			entityManager.merge(bank);
		}
		else {
			System.out.println("unable to process due to insuffecient funds");
		}
		return bank;
	}

	@Override
	public Bank fundTransfer(int accNumber, int accNumber2, int amount) {
		// TODO Auto-generated method stub
		Bank bank=entityManager.find(Bank.class,accNumber);
		Bank bank1=entityManager.find(Bank.class,accNumber2);
		int bal1=bank.getBalance();
		int bal2=bank1.getBalance();
		if(bal1>amount) {
			int amount1=bal1-amount;
			int amount2=bal2+amount;
			bank.setBalance(amount1);
			bank1.setBalance(amount2);
			entityManager.merge(bank);
			entityManager.merge(bank1);
		}
		else {
			System.out.println("unable to process due to insuffecient funds");
		}
		return bank;
	}
}
