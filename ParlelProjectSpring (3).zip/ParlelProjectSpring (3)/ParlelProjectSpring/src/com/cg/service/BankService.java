package com.cg.service;

import com.cg.entity.Bank;

public interface BankService {
	public void createAccount(Bank bank);
	public Bank showBalance(int accNumber);
	public Bank deposite(int accNumber,int amount);
	public Bank withdraw(int accNumber,int amount);
	public Bank fundTransfer(int accNumber,int accNumber2,int amount);
}
