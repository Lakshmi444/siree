package com.cg.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.BankDao;
import com.cg.entity.Bank;

@Service
@Transactional
public class BankServiceImpl implements BankService{

	@Autowired
	BankDao bankDao;
	
	@Override
	public void createAccount(Bank bank) {
		// TODO Auto-generated method stub
		bankDao.createAccount(bank);
	}

	@Override
	public Bank showBalance(int accNumber) {
		// TODO Auto-generated method stub
		return bankDao.showBalance(accNumber);
	}

	@Override
	public Bank deposite(int accNumber, int amount) {
		// TODO Auto-generated method stub
		return bankDao.deposite(accNumber, amount);
	}

	@Override
	public Bank withdraw(int accNumber, int amount) {
		// TODO Auto-generated method stub
		return bankDao.withdraw(accNumber, amount);
	}

	@Override
	public Bank fundTransfer(int accNumber, int accNumber2, int amount) {
		// TODO Auto-generated method stub
		return bankDao.fundTransfer(accNumber, accNumber2, amount);
	}

}
