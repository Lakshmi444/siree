 package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Bank;
import com.cg.service.BankService;

@RestController
public class Controller {

	
	@Autowired
	BankService bankService;
	
	@RequestMapping(value = "/bank/create/{balance}/{cusName}/{address}",
			 method = RequestMethod.GET, headers="Accept=application/json")
	public Bank createAccount(@PathVariable String cusName,
			@PathVariable int balance,@PathVariable String address) {
		Bank bank=new Bank();
		bank.setAddress(address);
		bank.setBalance(balance);
		bank.setCusName(cusName);
		bankService.createAccount(bank);
		return bank;
	}
	@RequestMapping(value = "/bank/show/{accNumber}",method=RequestMethod.GET,headers="Accept=application/json")
	public Bank showBalance(@PathVariable int accNumber) {
		Bank bank=bankService.showBalance(accNumber);
		return bank;
	}
	@RequestMapping(value = "/bank/deposite/{accNumber}/{amount}",method=RequestMethod.GET,headers="Accept=application/json")
	public Bank deposite(@PathVariable int accNumber,@PathVariable int amount) {
		Bank bank=bankService.deposite(accNumber, amount);
		return bank;
	}
	@RequestMapping(value = "/bank/withdraw/{accNumber}/{amount}",method=RequestMethod.GET,headers="Accept=application/json")
public Bank withdraw(@PathVariable int accNumber,@PathVariable int amount) {
		Bank bank=bankService.withdraw(accNumber, amount);
		return bank;
	}
	@RequestMapping(value = "/bank/fundtransfer/{accNumber}//{accNumber2}/{amount}",method=RequestMethod.GET,headers="Accept=application/json")
	public Bank fundtransfer(@PathVariable int accNumber,@PathVariable int accNumber2,@PathVariable int amount) {
		Bank bank=bankService.fundTransfer(accNumber, accNumber2, amount);
		return bank;
	}
}
