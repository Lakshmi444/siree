package com.cg.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="bankspring")
public class Bank implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int accountNum;
	
	private int balance;
	private String cusName;
	private String address;
	public int getAccountNum() {
		return accountNum;
	}
	public void setAccountNum(int accountNum) {
		this.accountNum = accountNum;
	}
	
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public String getCusName() {
		return cusName;
	}
	public void setCusName(String cusName) {
		this.cusName = cusName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Bank(int accountNum, int pin, int balance, String cusName, String address) {
		super();
		this.accountNum = accountNum;
		
		this.balance = balance;
		this.cusName = cusName;
		this.address = address;
	}
	public Bank() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Bank [accountNum=" + accountNum + ", balance=" + balance + ", cusName=" + cusName
				+ ", address=" + address + "]";
	}
	

}
