package com.cg.service;

import com.cg.entity.Account;

public interface AccountService {

	public Account createAccount(Account acc);
	public Account showBalance(int accNo);
	public Account deposit(int accNo,double amount);
	public Account withDraw(int accNo,double amount);
/*	public Account fundTransfer(int accNo,int accNo1,double amount);
*/	public Account printTransactions(int accNo);
	
}
