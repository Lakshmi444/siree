package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entity.Account;

@Repository
public class AccountDaoImpl implements AccountDao {

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public  Account createAccount(Account acc) {
		entityManager.persist(acc);
		entityManager.flush();
		return acc;
	}

	@Override
	public Account showBalance(int accNo) {
		Account  acc= entityManager.find(Account.class, accNo);
		if(acc!=null)
		{
			
		return acc;
		}
		else {
			
			return null;
		}	
		
	}

	@Override
	public Account deposit(int accNo, double amount) {
		
		Account  acc= entityManager.find(Account.class, accNo);
		String str="SELECT acc.accbalance FROM Account acc WHERE acc.accNumber=:num";
		TypedQuery<Double> query=entityManager.createQuery(str,Double.class);
		query.setParameter("num",accNo);
		Double e=query.getSingleResult();
		Double balance = e+amount;
		acc.setAccbalance(balance);
	
        return acc;
	
		
	}

	@Override
	public Account withDraw(int accNo, double amount) {
	
		Account  acc= entityManager.find(Account.class, accNo);
		String str="SELECT acc.accbalance FROM Account acc WHERE acc.accNumber=:num";
		TypedQuery<Double> query=entityManager.createQuery(str,Double.class);
		query.setParameter("num",accNo);
		Double e=query.getSingleResult();
		double balance = e-amount;
		acc.setAccbalance(balance);
	
		return acc;
	}

/*	@Override
	public Account fundTransfer(int accNo,int accNo1, double amount) {
		 
		  Account  acc= entityManager.find(Account.class, accNo);
		  String str="SELECT acc.balance FROM Account acc WHERE acc.accNumber=:num";
		  TypedQuery<Double> query=entityManager.createQuery(str,Double.class);
		  query.setParameter("num",accNo);
		  Double e=query.getSingleResult();
		  double balance = e-amount;
			acc.setAccbalance(balance);
			Account  acc1= entityManager.find(Account.class, accNo1);
			  String str1="SELECT acc.accbalance FROM Account acc WHERE acc.accNumber=:num";
			  TypedQuery<Double> query1=entityManager.createQuery(str1,Double.class);
			  query1.setParameter("num",accNo1);
			  Double e1=query.getSingleResult();
			  double balance1 = e1+amount;
				acc1.setAccbalance(balance1);

			return acc;
	}*/

	@Override
	public Account printTransactions(int accNo) {
		
			
			  Account  acc= entityManager.find(Account.class, accNo);
		      return acc;
	}


}
