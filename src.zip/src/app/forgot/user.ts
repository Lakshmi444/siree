export class User{
    username:string;
    password:string;
    securityQuestion:string;
    answer:string;
    role:string;
}