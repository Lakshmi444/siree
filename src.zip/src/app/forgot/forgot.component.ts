import { Component, OnInit } from '@angular/core';
import { ForgotService } from '../forgot.service';
import { User } from './user';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-forgot',
  templateUrl: './forgot.component.html',
  styleUrls: ['./forgot.component.css']
})
export class ForgotComponent implements OnInit {
  userForm:FormGroup
user:User[];
gotUser:User;
  constructor(private service:ForgotService) { }

  ngOnInit() {
    this.userForm=new FormGroup({
      username : new FormControl(null,[Validators.required])
     });
     this.service.getUsers().subscribe(data=>this.user=data);
  }
  onSubmit(user:User){
  let arr=this.user.filter(p=>p.username==user.username);
  if(arr.length>0){

    arr.map(p=>this.gotUser=p);
    console.log(this.gotUser);
  }
  else{
    alert("enter valid username");
  }

}
}
