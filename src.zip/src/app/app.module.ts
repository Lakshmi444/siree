import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { HomepageComponent } from './homepage/homepage.component';
import { ForgotComponent } from './forgot/forgot.component';
import {HttpClientModule} from '@angular/common/http';
import { Route,RouterModule } from "@angular/router";
import { ResetComponent } from './reset/reset.component';

const routes :   Route[]=[
  {
    path :"forgot",
    component :  ForgotComponent
  
  },
  {
    path :"home",
    component :  HomepageComponent
  
  },]
@NgModule({
  declarations: [
    AppComponent,
    HomepageComponent,
    ForgotComponent,
    ResetComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(routes),
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
