import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { Route,RouterModule } from '@angular/router';
import {HttpClientModule} from '@angular/common/http';
import { AppComponent } from './app.component';
import { ElectronicdevicesComponent } from './electronicdevices/electronicdevices.component';
import { FashionComponent } from './fashion/fashion.component';
import { ClothingComponent } from './clothing/clothing.component';
import { AllproductsComponent } from './allproducts/allproducts.component';

const routes :Route[]=[
  {
    path: 'electronic',
    component:ElectronicdevicesComponent
  },
  {
    path: 'fashion',
    component:FashionComponent
  },
  {
    path: 'clothing',
    component:ClothingComponent
  },
  {
    path: 'all',
    component:AllproductsComponent
  },]
@NgModule({
  declarations: [
    AppComponent,
    ElectronicdevicesComponent,
    FashionComponent,
    ClothingComponent,
    AllproductsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
