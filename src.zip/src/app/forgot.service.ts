import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from './forgot/user';

@Injectable({
  providedIn: 'root'
})
export class ForgotService {

  users:User[];
  user:User;
  username:string;
  password:string;
  question:string;
  answer:string;
  url:string="assets/users.json"
  constructor(private http:HttpClient) { }

  getUsers():Observable<User[]>{
    return this.http.get<User[]>(this.url);
  }

  findUser(user:User):User{
    this.http.get<User[]>(this.url).subscribe(data=>this.users==data);
    let arr=this.users.filter(p=>p.username==user.username);

    if(arr.length>0){
      arr.map(p=>this.user=p);
      return this.user
    }
    else{
      alert("enter valid username");
    }
  }
}
