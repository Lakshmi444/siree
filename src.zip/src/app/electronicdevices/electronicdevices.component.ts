import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../products.service';
import { Router } from '@angular/router';
import { Products } from './products';

@Component({
  selector: 'app-electronicdevices',
  templateUrl: './electronicdevices.component.html',
  styleUrls: ['./electronicdevices.component.css']
})
export class ElectronicdevicesComponent implements OnInit {
products:Products[];
similarProducts:Products[];
category:string="electronicdevice";
product:Products;
  constructor(private srvice:ProductsService,private router:Router) { }

  ngOnInit() {
    this.srvice.getProducts().subscribe(data=>this.products=data);
    this.similarProducts=this.products.filter(p=>p.category==this.category);
    this.product=this.srvice.read();
    
  }


}
