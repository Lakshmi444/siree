import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Products } from './allproducts/products';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  product:Products;
  Url="assets/booklist.json"
  constructor(private http:HttpClient) { }

  getProducts():Observable<Products[]>{
    return this.http.get<Products[]>(this.Url);
   
  }
  store(product:Products):Products{ 
    this.product=product;
    return product;
  }
read():Products{
  return this.product;
}
}
