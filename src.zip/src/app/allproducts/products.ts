export class Products{

    id: number
    title: string
    year: number
    author: string
    image:string
    category:string
}