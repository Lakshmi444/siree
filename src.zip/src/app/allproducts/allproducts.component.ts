import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../products.service';
import { Products } from './products';
import { Router } from '@angular/router';

@Component({
  selector: 'app-allproducts',
  templateUrl: './allproducts.component.html',
  styleUrls: ['./allproducts.component.css']
})
export class AllproductsComponent implements OnInit {

  products:Products[];

  category:string='electronicdevice';
  constructor(private service:ProductsService,private router:Router) { }

  ngOnInit() {
    this.service.getProducts().subscribe(data=>this.products=data);
  }
  view(product:Products){
     this.service.store(product);
     if(product.category===this.category)
     this.router.navigate(['/electronic'])
  }

}
