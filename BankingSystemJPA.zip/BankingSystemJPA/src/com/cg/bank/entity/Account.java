package com.cg.bank.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Account_JPA")
public class Account implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private final  String bankName = "XYZ Bank";
	private final String branch = "Polavaram";
	private final String ifscCode = "XYZB000229";
	@Id
	private String accNumber ;
    private double accbalance;
	public Account()
	{
		super();
		
	}
	public Account(String accNumber, double accbalance) {
		super();
		this.accNumber = accNumber;
		this.accbalance = accbalance;
	}
	public String getAccNumber() {
		return accNumber;
	}
	public void setAccNumber(String accNumber) {
		this.accNumber = accNumber;
	}
	public double getAccbalance() {
		return accbalance;
	}
	public void setAccbalance(double accbalance) {
		this.accbalance = accbalance;
	}
	public String getBankName() {
		return bankName;
	}
	public String getBranch() {
		return branch;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	@Override
	public String toString() {
		return "Account [bankName=" + bankName + ", branch=" + branch + ", ifscCode=" + ifscCode + ", accNumber="
				+ accNumber + ", accbalance=" + accbalance + "]";
	}
	

	
}
