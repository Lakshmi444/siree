
package com.cg.bank.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Customer_JPA")
public class Customer implements Serializable {

	private static final long serialVersionUID = 1L;
	private String cusName;
	private String cusNumber;
	private int cusAge;
	private String mailId;
	private String cusAadharNo;
	private String city;
	private int pinCode;
	@Id
	private String accNo;

	public String getAccNo() {
		return accNo;
	}
	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}
	public Customer()
	{
		super();
	}

	public Customer(String cusName, String cusNumber, int cusAge, String mailId, String cusAadharNo, String city,
			int pinCode, String accNo) {
		super();
		this.cusName = cusName;
		this.cusNumber = cusNumber;
		this.cusAge = cusAge;
		this.mailId = mailId;
		this.cusAadharNo = cusAadharNo;
		this.city = city;
		this.pinCode = pinCode;
		this.accNo = accNo;
	}
	public String getCusName() {
		return cusName;
	}
	public void setCusName(String cusName) {
		this.cusName = cusName;
	}
	public String getCusNumber() {
		return cusNumber;
	}
	public void setCusNumber(String cusNumber) {
		this.cusNumber = cusNumber;
	}
	public int getCusAge() {
		return cusAge;
	}
	public void setCusAge(int cusAge) {
		this.cusAge = cusAge;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public String getCusAadharNo() {
		return cusAadharNo;
	}
	public void setCusAadharNo(String cusAadharNo) {
		this.cusAadharNo = cusAadharNo;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getPinCode() {
		return pinCode;
	}
	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}
	@Override
	public String toString() {
		return "Customer [cusName=" + cusName + ", cusNumber=" + cusNumber + ", cusAge=" + cusAge + ", mailId=" + mailId
				+ ", cusAadharNo=" + cusAadharNo + ", city=" + city + ", pinCode=" + pinCode + ", accNo=" + accNo + "]";
	}
	
	
}
