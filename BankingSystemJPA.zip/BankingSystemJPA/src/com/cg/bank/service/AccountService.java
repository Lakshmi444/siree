package com.cg.bank.service;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;

public interface AccountService {


	public String createAccount(Customer c,Account acc);
	public Double showBalance(String accNo);
	public Double deposit(String accNo,double amount);
	public Double withDraw(String accNo,double amount);
	public Double fundTransfer(String accNo,String accNo1,double amount);
	public Account printTransactions(String accNo);
	public Boolean validateCustomerName(String name);
	public Boolean validateCustomerNumber(String number);
	public Boolean validateCustomerMailId(String mailId);
	public Boolean validateCustomerAadharNo(String cusAadharNo);
}
