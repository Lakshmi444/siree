package com.cg.bank.dao;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;

public interface AccountDAO {
	
	public String createAccount(Customer c,Account acc);
	public double showBalance(String accNo);
	public double deposit(String accNo,double amount);
	public double withDraw(String accNo,double amount);
	public double fundTransfer(String accNo,double amount);
	public Account printTransactions(String accNo);
	
}
