package com.cg.bank.dao;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;

public interface AccountDAO {
	
	public String createAccount(Customer c,Account acc);
	public Double showBalance(String accNo);
	public Double deposit(String accNo,double amount);
	public Double withDraw(String accNo,double amount);
	public Double fundTransfer(String accNo,String accNo1,double amount);
	public Account printTransactions(String accNo);
	
}
