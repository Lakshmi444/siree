package com.cg.bank.dao;



import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.hibernate.sql.ordering.antlr.Factory;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.util.CollectionUtil;

public class AccountDAOImpl implements AccountDAO{
	private  EntityManagerFactory factory;
	private EntityManager em;

	public AccountDAOImpl() {
		em = CollectionUtil.getEntityManager();
	}
	@Override
	public String createAccount(Customer c, Account acc) {
		em.getTransaction().begin();
		em.persist(c);
		em.persist(acc);
		em.getTransaction().commit();
		factory.close();
		return acc.getAccNumber();
		
		
	}

	@Override
	public double showBalance(String accNo) {
		em.getTransaction().begin();
		Account acc = em.find(Account.class, accNo);
		em.getTransaction().commit();
		factory.close();
		return acc.getAccbalance();
	}

	@Override
	public double deposit( String accNo,double amount) {
		em.getTransaction().begin();
		Account acc = em.find(Account.class, accNo);
		double balance = acc.getAccbalance()+amount;
		em.getTransaction().commit();
		factory.close();
		return balance;
	}

	@Override
	public double withDraw( String accNo,double amount) {
		em.getTransaction().begin();
		Account acc =  em.find(Account.class, accNo);
		double balance = acc.getAccbalance()-amount;
		em.getTransaction().commit();
		factory.close();
		return balance;
	}

	@Override
	public double fundTransfer(String accNo, double amount) {
		  em.getTransaction().begin();
		  Account acc = em.find(Account.class, accNo);
		  double balance = acc.getAccbalance()-amount;
		  em.getTransaction().commit();
			factory.close();
			return balance;
			
	}

	@Override
	public Account printTransactions(String accNo) {
		  em.getTransaction().begin();
		  Account acc = em.find(Account.class, accNo);
		  em.getTransaction().commit();
			factory.close();
	     return acc;
	}

	
}
