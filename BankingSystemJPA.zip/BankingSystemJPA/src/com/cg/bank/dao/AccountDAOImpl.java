package com.cg.bank.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.TypedQuery;
import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.util.CollectionUtil;


public class AccountDAOImpl implements AccountDAO{
	private  EntityManagerFactory factory;
	private EntityManager em;

	public AccountDAOImpl() {
		em = CollectionUtil.getEntityManager();
	}
	@Override
	public String createAccount(Customer c, Account acc) {
		em.getTransaction().begin();
		em.persist(c);
		em.persist(acc);
	em.getTransaction().commit();
		return acc.getAccNumber();
		
		
	}

	@Override
	public Double showBalance(String accNo) {
		em.getTransaction().begin();
		Account  acc= em.find(Account.class, accNo);
		if(acc!=null)
		{
		em.getTransaction().commit();
		return acc.getAccbalance();
		}
		else {
			em.getTransaction().commit();
			return 0.0;
		}
	}
		

	@Override
	public Double deposit( String accNo,double amount) {
		em.getTransaction().begin();
		Account  acc= em.find(Account.class, accNo);
		String str="SELECT acc.accbalance FROM Account acc WHERE acc.accNumber=:num";
		TypedQuery<Double> query=em.createQuery(str,Double.class);
		query.setParameter("num",accNo);
		Double e=query.getSingleResult();
		Double balance = e+amount;
		acc.setAccbalance(balance);
		em.getTransaction().commit();
        return balance;
	}

	@Override
	public Double withDraw( String accNo,double amount) {
		em.getTransaction().begin();
		Account  acc= em.find(Account.class, accNo);
		String str="SELECT acc.accbalance FROM Account acc WHERE acc.accNumber=:num";
		TypedQuery<Double> query=em.createQuery(str,Double.class);
		query.setParameter("num",accNo);
		Double e=query.getSingleResult();
		double balance = e-amount;
		acc.setAccbalance(balance);
		em.getTransaction().commit();
		return balance;
	}

	@Override
	public Double fundTransfer(String accNo,String accNo1, double amount) {
		  em.getTransaction().begin();
		  Account  acc= em.find(Account.class, accNo);
		  String str="SELECT acc.accbalance FROM Account acc WHERE acc.accNumber=:num";
		  TypedQuery<Double> query=em.createQuery(str,Double.class);
		  query.setParameter("num",accNo);
		  Double e=query.getSingleResult();
		  double balance = e-amount;
		  acc.setAccbalance(balance);
			Account  acc1= em.find(Account.class, accNo1);
			String str1="SELECT acc.accbalance FROM Account acc WHERE acc.accNumber=:num";
			TypedQuery<Double> query1=em.createQuery(str1,Double.class);
			query1.setParameter("num",accNo1);
			Double e1=query1.getSingleResult();
			Double balance1 = e1+amount;
			acc1.setAccbalance(balance1);
		  em.getTransaction().commit();
         return balance;
			
	}

	@Override
	public Account printTransactions(String accNo) {
		  em.getTransaction().begin();
		  Account  acc= em.find(Account.class, accNo);
		//  Customer c = em.find(Customer.class, accNo);
		  em.getTransaction().commit();
		 
	      return acc;
	}

	
}
