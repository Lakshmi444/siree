package com.cg.bank.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

import com.cg.bank.dao.AccountDAO;
import com.cg.bank.dao.AccountDAOImpl;
import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;



class AccountDAOImplTest {
	static AccountDAO accDAO=new AccountDAOImpl();
/* 	@Test
	public void createAccountTest(){
	Customer c = new Customer("Mounika","9874563215",25,"mounika@gmail.com","456321089654","Vij",523002,"983929185");
	Account acc = new Account("983929185",3354.0);
	
	String result=accDAO.createAccount(c,acc);
    assertEquals("983929185",result);
	
	} */
 	@Test
 	public void showBalance() 
 	{
 		double bal = accDAO.showBalance("670477504");
 		Assert.assertEquals(Double.doubleToLongBits(4000),Double.doubleToLongBits(bal));
 				
 	}
 	@Test
 	public void deposit() 
 	{
 		double bal = accDAO.deposit("670477504", 1000);
 		assertEquals(Double.doubleToLongBits(5000), Double.doubleToLongBits(bal));
 	}
 	@Test
 	public void withdraw() 
 	{
 		double bal = accDAO.withDraw("670477504", 5000);
 		assertEquals(Double.doubleToLongBits(4000), Double.doubleToLongBits(bal));
 	}
 	@Test 
 	public void fundTransfer() 
 	{
 		double bal = accDAO.fundTransfer("670477504","639223566", 2000);
 		assertEquals(Double.doubleToLongBits(2000), Double.doubleToLongBits(bal));
 }
}

