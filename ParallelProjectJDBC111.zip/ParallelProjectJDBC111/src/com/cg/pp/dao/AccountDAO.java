package com.cg.pp.dao;

import java.sql.SQLException;
import java.util.HashMap;
import com.cg.pp.entity.Account;

public interface AccountDAO {


	public Account deposit(double amt,String acc) throws ClassNotFoundException, SQLException;
	public void withdraw(double res, String acc) throws ClassNotFoundException, SQLException;
	public Account showbalance(String accNumber) throws ClassNotFoundException, SQLException;
	public int createaccount(Account b) throws SQLException, ClassNotFoundException;
}