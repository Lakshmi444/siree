package com.cg.pp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.pp.entity.Account;
import com.cg.pp.jdbc.JDBC;

public class AccountDAOIMPl implements AccountDAO {
	
	
	
	
	@Override
	public int createaccount(Account b) throws SQLException, ClassNotFoundException {
		Connection c=JDBC.connect();
		//Statement stmt=c.createStatement();
		PreparedStatement pst=c.prepareStatement("INSERT INTO ACCOUNT VALUES(?,?,?,?,?,?)");
		pst.setString(1, b.getBankName());
		pst.setString(2, b.getBranch());
		pst.setString(3, b.getAccNumber());
		pst.setDouble(4, b.getAccbalance());
		pst.setString(5, b.getCustomername());
		pst.setString(6, b.getCustomermobno());
		pst.executeUpdate();
		return 0;

		
	}

	@Override
	public Account showbalance(String accNumber) throws ClassNotFoundException, SQLException {
		Connection c = JDBC.connect();
		Statement stmt = c.createStatement();
		    ResultSet res = stmt.executeQuery("SELECT * FROM ACCOUNT WHERE ACCNUMBER=' " + accNumber + " ' ");
		while (res.next()) { 
			
			String bankname=res.getString(1);
			String branch=res.getString(2);
			String accno = res.getString(accNumber);
			double accbalance = res.getDouble(4);
			String customername=res.getString(5);
			String customermobno=res.getString(6);
			Account acc = new Account(bankname, branch,accno, accbalance,customername,customermobno);
			return acc;
		}
		c.commit();
		return null;
	}

	@Override
	public void withdraw(double res, String acc) throws ClassNotFoundException, SQLException {

		Connection c=JDBC.connect();
		Statement stmt=c.createStatement();
		ResultSet res1 =stmt.executeQuery("update ACCOUNT set balance='"+res+"'where ACCNUMBER='"+acc+"'"); 	 
				c.commit();
		
	}

	/*@Override
	public void createaccount(Account a, Customer b) throws SQLException, ClassNotFoundException {
		Connection con = JDBC.connect();
	System.out.println("dao calling");

		PreparedStatement pst1 = con.prepareStatement("INSERT INTO Account VALUES(?,?,?,?,?)");

		pst1.setString(1, a.getAccNumber());
		pst1.setDouble(2, a.getAccbalance());
		pst1.setString(3, a.getBankName());
		pst1.setString(4, a.getBranch());
		pst1.setString(5, a.getIfscCode());

		pst1.execute();
		System.out.println("inserted");
		PreparedStatement pst = con.prepareStatement("INSERT INTO customer VALUES(?,?,?,?,?,?,?,?)");
		pst.setString(1, a.getAccNumber());
		pst.setString(2, b.getCusName());
		pst.setString(3, b.getCusNumber());
		pst.setInt(4, b.getCusAge());
		pst.setString(5, b.getMailId());
		pst.setString(6, b.getCusAadharNo());
		pst.setString(7, b.getCity());
		pst.setInt(8, b.getPinCode());
		pst.execute();
		System.out.println("inerts2");
		con.commit();
	}*/

	@Override
	public Account deposit(double updatedAmt, String s) throws SQLException, ClassNotFoundException {
		Connection c = JDBC.connect();
		Statement stmt = c.createStatement();
		ResultSet res1 = stmt.executeQuery("update ACCOUNT set balance='" + updatedAmt + "'where ACCNUMBER='" + s + "'");
		while (res1.next()) {
			String bankname=res1.getString(1);
			String branch=res1.getString(2);
			String accno = res1.getString(3);
			double accbalance = res1.getDouble(4);
			String customername=res1.getString(5);
			String customermobno=res1.getString(6);
			Account acc = new Account(bankname, branch,accno, accbalance,customername,customermobno);
			return acc;
		}
		c.commit();
		return null;

	}

	
}
