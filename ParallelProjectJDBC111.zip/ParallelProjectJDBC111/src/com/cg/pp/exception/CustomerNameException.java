package com.cg.pp.exception;

public class CustomerNameException extends Exception {

	public CustomerNameException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
