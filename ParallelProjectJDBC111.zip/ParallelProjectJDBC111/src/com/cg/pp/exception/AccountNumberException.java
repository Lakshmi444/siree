package com.cg.pp.exception;

public class AccountNumberException extends Exception {

	public AccountNumberException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
