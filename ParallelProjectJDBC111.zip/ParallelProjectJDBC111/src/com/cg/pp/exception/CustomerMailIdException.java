package com.cg.pp.exception;

public class CustomerMailIdException extends Exception {

	public CustomerMailIdException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}


}
