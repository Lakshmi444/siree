package com.cg.pp.exception;

public class CustomerAadharException extends Exception {

	public CustomerAadharException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}


}
