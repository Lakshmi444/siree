package com.cg.pp.service;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.pp.dao.AccountDAO;
import com.cg.pp.dao.AccountDAOIMPl;
import com.cg.pp.entity.Account;


public class AccountServiceImpl implements AccountService {

	
	 AccountDAO adao=new AccountDAOIMPl();
	@Override
	public boolean validateCustomerName(String cusName) {
		Pattern pattern = Pattern.compile("^[A-Z]{1}[a-z]{2,}");
		Matcher custnameMatch = pattern.matcher(cusName);
		if(custnameMatch.matches())
		{
			return true;
		}
		return false;
	}

	@Override
	public boolean validateCustomerNumber(String cusNo) {
		Pattern pattern = Pattern.compile("[0-9]{10}");
		Matcher custnumMatch = pattern.matcher(cusNo);
		if(custnumMatch.matches())
		{
			return true;
		}
		return false;
	}



	@Override
	public int   createaccount(Account b) throws ClassNotFoundException, SQLException {
		System.out.println("service calling");
	        adao.createaccount(b);
		
		 return 0;
	}

	@Override
	public Account showbalance(String a) throws ClassNotFoundException, SQLException {
		Account ac=adao.showbalance(a);
		return ac;
	}

	@Override
	public Account deposit(double updatedAmt, String s) throws ClassNotFoundException, SQLException {
		Account acc=adao.deposit(updatedAmt, s);
		return acc;
		
	}

	@Override
	public void withdraw(double res, String acc) throws ClassNotFoundException, SQLException {
		adao.deposit(res,acc);
		
	}

	
}