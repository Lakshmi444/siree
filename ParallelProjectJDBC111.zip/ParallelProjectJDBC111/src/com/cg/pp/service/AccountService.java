package com.cg.pp.service;

import java.sql.SQLException;
import com.cg.pp.entity.Account;
public interface AccountService {

	boolean validateCustomerName(String cusName);
	boolean validateCustomerNumber(String cusNo);
	public int createaccount(Account b) throws ClassNotFoundException, SQLException;
	public Account showbalance(String a) throws ClassNotFoundException, SQLException;
	public Account deposit(double updatedAmt, String s) throws ClassNotFoundException, SQLException;
	public void withdraw(double res, String acc) throws ClassNotFoundException, SQLException;
	
	
	




}
