package com.cg.pp.ui;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Scanner;

import com.cg.pp.entity.Account;
import com.cg.pp.exception.AccountNumberException;
import com.cg.pp.exception.BalanceException;
import com.cg.pp.exception.CustomerAadharException;
import com.cg.pp.exception.CustomerAgeException;
import com.cg.pp.exception.CustomerMailIdException;
import com.cg.pp.exception.CustomerNameException;
import com.cg.pp.exception.CustomerNumberException;
import com.cg.pp.service.AccountService;
import com.cg.pp.service.AccountServiceImpl;

public class Accountmain {

	static Scanner sc = null;
	static AccountService accservice=null;
	static Account acc ;

	public static void main(String[] args) throws AccountNumberException, BalanceException, ClassNotFoundException, SQLException  {
		 sc = new Scanner(System.in);
		 accservice = new AccountServiceImpl();
		 int choice;
		while(true)
		{
		 System.out.println("\n What U Want To DO?");
		 System.out.println("1.Create Account\n2.Show Balance");
		 System.out.println("3.Deposit\n4.WithDraw");
		 //System.out.println("5.Fund Transfer\n6.Print Transactions");
		 System.out.println("5.Exit");
		 System.out.println("Enter Your Choice");
	
		 choice=sc.nextInt();
		 switch(choice)
		 {
		 case 1:
			 createAccount();
			 break;
		case 2:
			 showBalance();
			 break;
		 case 3:
			 deposit();
			 break;
			case 4:
			 withDraw();
			 break;
		 case 5:
			 System.exit(0);
		default:
				System.out.println("Select any Case");	 
				break;
		 }
	
	}
	}
	public static void withDraw() throws ClassNotFoundException, SQLException {
		System.out.println("Enter Your Account Number");
		String acc=sc.next();
		Account at=accservice.showbalance(acc);
		double d=at.getAccbalance();
		System.out.println("Your Account Balance is: "+d);
		System.out.println("Enter The Amount To Withdraw");
		double w=sc.nextDouble();
		if(d>w)
		{
			double res=at.setAccbalance(d-w);
			accservice.withdraw(res,acc);
			System.out.println("Account Balance is: "+res);
		}
		else {
			System.out.println("Need To Deposit More Money");
		}
		}
		
	
	public static void deposit() throws ClassNotFoundException, SQLException {
		System.out.println("Enter your Account Number");
		String s=sc.next();
		Account act=accservice.showbalance(s);
		System.out.println(act.getAccNumber()+"\n"+ "Enter the amount to deposit");
		double amt=sc.nextDouble();
		double dou=act.getAccbalance();
		double updatedAmt=act.setAccbalance(dou+amt);
		accservice.deposit(updatedAmt,s);
		System.out.println("Account Balance is: "+updatedAmt);			
	}
	public static void showBalance() throws ClassNotFoundException, SQLException {
		System.out.println("Enter your Account Number:");
		String a=sc.next();
		Account act=accservice.showbalance(a);
		System.out.println(act.getAccNumber()+ " Your Account Balance Is: "+act.getAccbalance());	
	}
	
	public static void createAccount() {
	while(true)
	{
	 System.out.println("Enter Customer Name");
	 String cusName=sc.next();
	 try
	 {
	 if(accservice.validateCustomerName(cusName))
	 {
		
		 System.out.println("Enter Customer Mobile Number");
		 String cusNo = sc.next();
		 try
		 {
		 if(accservice.validateCustomerNumber(cusNo))
		 {
				
					    String bankname="XYZBank";
					    String branch ="karapakkam";
					    String ifsccode ="XYZB00224";
					    int max= 999999999;
					    int min = 0;
					    int range = (max-min);
					    int accNo = (int)(Math.random()*range);
					    String accNumber = String.valueOf(accNo);
					    System.out.println("Enter initial amount to deposit");
					    double amount = sc.nextDouble();
					    Account acc=new Account(bankname,branch,accNumber,amount,cusName,cusNo);
                        accservice.createaccount(acc);
                        System.out.println("Your Account Successfully Created  "+accNumber+ "\n Bank Name : "+acc.getBankName()+"\n Branch Name :"+acc.getBranch()+" \n Account Balance :"+acc.getAccbalance());
					
		 }
		 else
		 {
			 throw new CustomerNumberException(cusNo);
		 }
		 }
		 catch(Exception ex)
		 {
			
		 }
	 }
	 else
	 {
		 throw new CustomerNameException(cusName);
		 
	 }
	 }
    catch(Exception exc)
	 {
		
	 }
	 break;
	}
		
	}
	
}


