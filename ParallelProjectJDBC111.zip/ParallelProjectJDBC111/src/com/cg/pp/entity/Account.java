package com.cg.pp.entity;

public class Account {
	
		private   String bankName;
		private  String branch;
		private String accNumber ;
	    private double accbalance;
	    private String customername;
	    private String customermobno;
	    
	    
		public Account(String bankName, String branch, String accNumber, double accbalance, String customername,
				String customermobno) {
			super();
			this.bankName = bankName;
			this.branch = branch;
			this.accNumber = accNumber;
			this.accbalance = accbalance;
			this.customername = customername;
			this.customermobno = customermobno;
		}
		
		public Account()
		{
			super();
		}

		public String getBankName() {
			return bankName;
		}

		public void setBankName(String bankName) {
			this.bankName = bankName;
		}

		public String getBranch() {
			return branch;
		}

		public void setBranch(String branch) {
			this.branch = branch;
		}

		public String getAccNumber() {
			return accNumber;
		}

		public void setAccNumber(String accNumber) {
			this.accNumber = accNumber;
		}

		public double getAccbalance() {
			return accbalance;
		}

		public double setAccbalance(double accbalance) {
			return this.accbalance = accbalance;
		}

		public String getCustomername() {
			return customername;
		}

		public void setCustomername(String customername) {
			this.customername = customername;
		}

		public String getCustomermobno() {
			return customermobno;
		}

		public void setCustomermobno(String customermobno) {
			this.customermobno = customermobno;
		}
		
		

		
	}

