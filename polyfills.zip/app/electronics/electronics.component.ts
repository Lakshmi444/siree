import { Component, OnInit } from '@angular/core';
import { BookService } from '../products.service';
import { IProducts } from 'src/products';


@Component({
  selector: 'app-electronics',
  templateUrl: './electronics.component.html',
  styleUrls: ['./electronics.component.css']
})
export class ElectronicsComponent implements OnInit {


  products : IProducts [] ;
  isUpdate : boolean = false;
  id : number ;
  title : string ;
  year : number;
  author: string;
/*   imageUrl:String; */
  constructor(private service : BookService) { }

  ngOnInit() {
    this.service.getBooks().subscribe(data => this.products=data);
  }
/* update(book:IBook)
{
  this.id=book.id;
  this.title=book.title;
  this.year=book.year;
  this.author=book.author;
  this.isUpdate=true;
}
delete(book : IBook)
{
  let arr = this.books.filter(p=>p.id !=book.id);
  this.books=arr;
} */

ngDetail()
{
  let arr=this.products.filter(p=>p.id !=this.id);
  arr.push({id : this.id, title: this.title,year:this.year,author:this.author});
  this.products=arr;
  this.isUpdate=false;
}
}
