import { Component, OnInit } from '@angular/core';
import { BookService } from '../products.service';
import { FormGroup, FormControl,Validators } from '@angular/forms';
import { IProducts } from 'src/products';
@Component({
  selector: 'app-fashion',
  templateUrl: './fashion.component.html',
  styleUrls: ['./fashion.component.css']
})
export class FashionComponent implements OnInit {
  books: IProducts[];
  userForm: FormGroup;

 
  constructor(private service:BookService) { }
  ngOnInit() {
  this.userForm=new FormGroup({
    id:new FormControl(),
    title:new FormControl('',[Validators.required,Validators.minLength(6)]),
    year:new FormControl(null,[Validators.required,Validators.pattern("^[0-9]{4}$")]),
    author:new FormControl()
  });
  this.service.getBooks().subscribe(data=>this.books=data);

}
  onSubmit(obj:any)
  {
    // this.books.map(p=>p.title).forEach(p=>console.log(p));
    let arr=this.books.filter(p=>p.id==obj.id);
    if(arr.length>0)
    {
    alert("Id alreday exists");
    }
    else{
        this.books.push({id:obj.id,title:obj.title,year:obj.year,author:obj.author});
    /* console.log(obj.year); */
    /* console.log(obj.year); */
    }
  }

}

