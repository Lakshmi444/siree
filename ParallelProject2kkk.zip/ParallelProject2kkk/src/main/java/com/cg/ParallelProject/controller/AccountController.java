package com.cg.ParallelProject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cg.ParallelProject.enity.Account;
import com.cg.ParallelProject.service.IAccount;

@RestController
public class AccountController {
	Account account= new Account();
	@Autowired
	IAccount accservice;
	
	
	@RequestMapping(value="/create/{name}/{amount}/{contact}/{type}", method = RequestMethod.POST,headers="Accept=application/json")
	public String createAccount(@PathVariable String name,@PathVariable int amount,@PathVariable String contact,@PathVariable String type) {
		
		account.setName(name);
		account.setBalance(amount);
		account.setContactNo(contact);
		account.setAccountType(type);
		account = accservice.createAccount(account);
		String res="Added Successfully and Trainee Id is: "+account.getAccountNo();
		return res;

		
	}
	@GetMapping(value="/showbalance/{accnum}")
	public int show(@PathVariable int accnum) {
		return accservice.showbalance(accnum);
	}
	@PostMapping(value="/deposit/{accnum}/{amount}")
	public void deposit(@PathVariable int accnum,@PathVariable int amount) {
		accservice.deposit(accnum, amount);
		
	}
	@PostMapping(value = "/withdraw/{accnum}/{amount}")
	public void withdraw(@PathVariable int accnum,@PathVariable int amount) {
		System.out.println(accnum+"--"+amount);
		accservice.withdraw(accnum, amount);
		}
	@PostMapping(value="/fundtransfer/{accnum}/{amount}")
	public void fundT(@PathVariable int accnum,@PathVariable int amount) {
		accservice.transfer(accnum, amount);
	}
}
