package com.cg.ParallelProject.service;

import com.cg.ParallelProject.enity.Account;

public interface IAccount {
public Account createAccount(Account account);
public int showbalance(int accnum);
public int deposit(int accnum,int deposit);
public int withdraw(int accnum,int withdraw);
public int transfer(int accnum,int transfer);
public String validateAccnum(int accnum);

}
