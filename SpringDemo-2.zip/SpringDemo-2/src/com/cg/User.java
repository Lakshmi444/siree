package com.cg;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

public class User {

	@NotEmpty(message="First Name is Mandatory")
	@Size(min=4,max=10,message="Min 4 & Max 8 Chars required")
	private  String firstName;
	@NotEmpty(message="Last Name is Mandatory")
	@Size(min=4,max=10,message="Min 4 & Max 8 Chars required")
	private String lastName;
	private char gender;
	@NotEmpty(message="Mial ID is Mandatory")
	@Email(message="Please enter valid mail ID")
	private String email;
	private String[] skillSet;
	private String city;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String[] getSkillSet() {
		return skillSet;
	}
	public void setSkillSet(String[] skillSet) {
		this.skillSet = skillSet;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
 	
	
}
