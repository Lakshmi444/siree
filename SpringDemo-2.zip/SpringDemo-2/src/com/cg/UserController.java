package com.cg;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(value="user")
public class UserController {

	@RequestMapping(value="/showRegister")
public String getRegister(Model model)
{
	model.addAttribute("user",new User());
	return "register";
}
	@RequestMapping(value="/checkRegister")
public String checkRegister(@ModelAttribute("user") @Valid User user,BindingResult result, Model model)
{
		if(result.hasErrors())
		{
			return "register";
		}
	  model.addAttribute("user",user);
	  return "registerSuccess";
}
	
	
}
