package com.cg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyController {
    @Autowired
	Login login;
	
	@RequestMapping(value="/showForm")
	public String dispalyForm(Model model)
	{
		model.addAttribute("login",login);
		return "login";
	}
	@RequestMapping(value="/checkLogin")
	public String checkLogin(Login login)
	{
		if(login.getUsername().equals("Lakshmi"))
		{
			return "success";
		}
		return "login";
	}
	
}
