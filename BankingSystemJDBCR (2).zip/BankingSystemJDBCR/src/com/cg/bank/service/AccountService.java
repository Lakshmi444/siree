package com.cg.bank.service;

import java.sql.SQLException;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;

public interface AccountService {


	public String createAccount(Customer c,Account acc)  throws ClassNotFoundException, SQLException;
	public double showBalance(String accNo)  throws ClassNotFoundException, SQLException;
	public double deposit(String accNo,double amount)  throws ClassNotFoundException, SQLException;
	public double withDraw(String accNo,double amount)  throws ClassNotFoundException, SQLException;
	public double fundTransfer(String accNo,double amount)  throws ClassNotFoundException, SQLException;
	public Account printTransactions(String accNo)  throws ClassNotFoundException, SQLException;
	public boolean validateCustomerName(String name);
	public boolean validateCustomerNumber(String number);
	public boolean validateCustomerMailId(String mailId);
	public boolean validateCustomerAadharNo(String cusAadharNo);
}
