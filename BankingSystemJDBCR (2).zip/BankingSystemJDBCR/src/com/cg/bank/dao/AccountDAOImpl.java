package com.cg.bank.dao;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.util.JDBC;

public class AccountDAOImpl implements AccountDAO{
		@Override
	public String createAccount(Customer c, Account acc) throws ClassNotFoundException, SQLException {
	Connection con = JDBC.connect();
	Statement stmt=con.createStatement();
	PreparedStatement pst=con.prepareStatement("INSERT INTO ACCOUNT VALUES(?,?)");
	pst.setString(1,acc.getAccNumber());
	pst.setDouble(2, acc.getAccbalance());
    PreparedStatement pst1=con.prepareStatement("INSERT INTO CUSTOMER VALUES(?,?,?,?,?,?,?,?)");
    pst1.setString(1, c.getCusName());
    pst1.setString(2, c.getCusNumber());
    pst1.setString(3, c.getMailId());
    pst1.setString(4, c.getCusAadharNo());
    pst1.setString(5, c.getCity());
    pst1.setString(6, c.getAccNo());
    pst1.setInt(7, c.getPinCode());
    pst1.setInt(8, c.getCusAge());
    return acc.getAccNumber();
	}

	@Override
	public double showBalance(String accNo)  throws ClassNotFoundException, SQLException {
		Connection con=jdbc.connect();
		Statement stmt =con.createStatement();
		ResultSet res =stmt.executeQuery("select accbalance from Account where accNumber='"+accNo+"' ");
		double bal = res.getDouble(accbalance);
		return  res;
	}

	@Override
	public double deposit( String accNo,double amount)  throws ClassNotFoundException, SQLException{
		
		return 0.0;
	}

	@Override
	public double withDraw( String accNo,double amount)  throws ClassNotFoundException, SQLException{
		 
		return 0.0;
	}

	@Override
	public double fundTransfer(String accNo, double amount)  throws ClassNotFoundException, SQLException{
		
		return 0.0;
	}

	@Override
	public Account printTransactions(String accNo)  throws ClassNotFoundException, SQLException {
		
		return 0.0;
	}

}
