package com.cg.bank.exception;

public class AccountException extends Exception{

	private static final long serialVersionUID = 1L;

	public AccountException(String s) {
		super(s);
	
	}
	

}
