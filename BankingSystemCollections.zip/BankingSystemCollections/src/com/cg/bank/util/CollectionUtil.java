package com.cg.bank.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;

public class CollectionUtil {

	private static Map<String,Account> accMap = new HashMap<String,Account>();
	private static Map<String,Customer> cusMap = new HashMap<String,Customer>(); 
	static
	{
		cusMap.put("945958742365", new Customer("Vidya","9490150279",25,"vidya9@gmail.com","432504659687","Eluru",521214));
		cusMap.put("894595874236", new Customer("Lakshmi","9866696047",27,"lakshmi999@gmail.com","432504659687","Hyderabad",521245));
		cusMap.put("785958742365", new Customer("Chandu","9491458096",23,"chandu@gmail.com","432504659687","Eluru",512243));
		cusMap.put("567558742365", new Customer("Vaasu","9492810110",29,"vaasu666@gmail.com","432504659687","Eluru",543214));
		cusMap.put("675958742365", new Customer("Raja","9490745409",30,"raja1212@gmail.com","432504659687","Eluru",532145));
		accMap.put("945958742365",new Account("945958742365",63456.0) );
		accMap.put("894595874236",new Account("894595874236",34526.0) );
		accMap.put("785958742365",new Account("785958742365",43134.0) );
		accMap.put("567558742365",new Account("567558742365",53211.0) );
		accMap.put("675958742365",new Account("675958742365",54677.0) );
	}
	
	public static void createAccount(Customer c, Account acc) {
		cusMap.put(acc.getAccNumber(), c);
		accMap.put(acc.getAccNumber(), acc);
	}
	public static double showBalance(String accNo) {
		if(accMap.containsKey(accNo))
		{
		Account acc= accMap.get(accNo);
		return acc.getAccbalance();
		}
		return 0;
	}
	public static double deposit( String accNo,double amount) {
			Account acc = accMap.get(accNo);
			double balance = acc.getAccbalance()+amount;
			accMap.put(acc.getAccNumber(),new Account(acc.getAccNumber(),balance) );
			return balance;
	
	}
	public static double withDraw(String accNo,double amount ) {
        	Account acc = accMap.get(accNo);
			double balance = acc.getAccbalance()-amount;
			accMap.put(acc.getAccNumber(),new Account(acc.getAccNumber(),balance) );
			return balance;
		
    }
	public static double fundTransfer(String accNo,String accNo1,double amount)
	{
		       Account acc = accMap.get(accNo);
		
		       double balance = acc.getAccbalance()-amount;
				accMap.put(acc.getAccNumber(),new Account(acc.getAccNumber(),balance));
				Account acc1 = accMap.get(accNo1);
				double balance1 = acc1.getAccbalance()+amount;
				accMap.put(acc1.getAccNumber(),new Account(acc1.getAccNumber(),balance1) );
				return balance;
			
	}
	public static Account printTransactions(String accNo)
	{
		if(accMap.containsKey(accNo))
		{
		  Account acc =accMap.get(accNo);
		  return acc;
		}
		return null;
		
	}
}
	

