package com.cg.bank.service;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;

public interface AccountService {


	public String createAccount(Customer c,Account acc);
	public double showBalance(String accNo);
	public double deposit(String accNo,double amount);
	public double withDraw(String accNo,double amount);
	public double fundTransfer(String accNo,String accNo1,double amount);
	public Account printTransactions(String accNo);
	public boolean validateCustomerName(String name);
	public boolean validateCustomerNumber(String number);
	public boolean validateCustomerMailId(String mailId);
	public boolean validateCustomerAadharNo(String cusAadharNo);
}
