package com.cg.bank.test;


import org.junit.Assert;
import org.junit.jupiter.api.Test;

import com.cg.bank.dao.AccountDAO;
import com.cg.bank.dao.AccountDAOImpl;
import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;

class AccountDAOImplTest {
	
	 AccountDAO accDAO=new AccountDAOImpl();
 	@Test
	public void createAccountTest(){
	Customer c = new Customer("Mounika","9874563215",25,"mounika@gmail.com","456321089654","Vij",523002);
	Account acc = new Account("207524890",3354.0);
	
	String result=accDAO.createAccount(c,acc);
    Assert.assertEquals("207524890",result);
	
	} 
 	@Test
 	public void showBalance() 
 	{
 		
 		double bal = accDAO.showBalance("785958742365");
 		Assert.assertEquals(Double.doubleToLongBits(43134.0),Double.doubleToLongBits(bal));
 	}
 	@Test
 	public void deposit() 
 	{
 		 
 		double bal = accDAO.deposit("785958742365", 200);
 		Assert.assertEquals(Double.doubleToLongBits(43334.0),Double.doubleToLongBits(bal));
 	}
 	@Test 
 	public void fundTransfer() 
 	{
 		
 		double bal = accDAO.fundTransfer("675958742365","785958742365", 100);
 		Assert.assertEquals(Double.doubleToLongBits(54577.0),Double.doubleToLongBits(bal));
 	}
}

