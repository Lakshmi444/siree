package com.cg.bank.ui;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Scanner;
import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.exception.AccountException;
import com.cg.bank.exception.CustomerException;
import com.cg.bank.service.AccountService;
import com.cg.bank.service.AccountServiceImpl;

public class RunMain {
    static Scanner sc = null;
	static AccountService accService = null;
	static Account acc ;
	static Customer c ;
	public static void main(String[] args) throws ClassNotFoundException, SQLException{
		 sc = new Scanner(System.in);
		 accService = new AccountServiceImpl();
		 int choice;
		while(true)
		{
		 System.out.println("\n What U Want To DO?");
		 System.out.println("1.Create Account\t 2.Show Balance\n");
		 System.out.println("3.Deposit\t 4.WithDraw\n");
		 System.out.println("5.Fund Transfer\t 6.Print Transactions\n");
		 System.out.println("7.Exit");
		 System.out.println("Enter Your Choice");
	   choice=sc.nextInt();
		 switch(choice)
		 {
		 case 1:
			 createAccount();
			 break;
		 case 2:
			 showBalance();
			 break;
		 case 3:
			 deposit();
			 break;
		 case 4:
			 withDraw();
			 break;
		 case 5:
			 fundTransfer();
			 break;
		 case 6:
			 printTransactions();
			 break;
		 case 7:
			 System.exit(0);
		default:
				System.out.println("Select any Case");	 
				break;
		 }
	
	}
	}
	public static void printTransactions() throws ClassNotFoundException, SQLException {
     while(true)
     {
		System.out.println("Enter the Account Number");
		String accNo = sc.next();
		double balance = accService.showBalance(accNo);
		try
		{
		if(balance!=0)
		{
			   acc = accService.printTransactions(accNo);
				System.out.println("Account Details  ");
				System.out.println("Bank Name  :"+acc.getBankName()+"\nBank Branch : "+acc.getBranch()+" \nBank IFSC Code : "+acc.getIfscCode()+" \nAccount Number  : "+acc.getAccNumber()+" \nAccount Balance : "+acc.getAccbalance()+" \n Date :"+LocalDate.now());
		
		}else
		{
		throw new AccountException(accNo);	
		}
		break;
		}
		catch(AccountException e)
		{
			System.out.println("Given Account Number  not exists,Enter Valid Account Number");
		}
     }
	}
	public static void fundTransfer() throws ClassNotFoundException, SQLException{
     while(true)
     {
		System.out.println("Enter the Account Number ");
		String accNo = sc.next();
	  double balance = accService.showBalance(accNo);
		try
		{
		if(balance!=0)
		{
			while(true)
			{
			System.out.println("Enter the amount to transfer");
			double amount = sc.nextDouble();
	    try
	    {
		
		if(amount<balance)
		{
			while(true)
			{
			System.out.println("Enter the Account Number to which account to transfer");
			String accNo1 = sc.next();
			double bal = accService.showBalance(accNo1);
			
			try
			{
			if(bal!=0)
			{
			
			double remainingAmount=0;
			try
			{
			 remainingAmount=accService.fundTransfer(accNo,accNo1, amount);
             System.out.println("Successfully Transferred");
			 System.out.println("Print Transactions\n");
			System.out.println("1.Yes \t 2.No");
			System.out.println("Enter Your Choice");
			
			int ch = sc.nextInt();
			
			switch(ch)
			{
			case 1:
				System.out.println("Balance in the Account : "+accNo+"  before transfer : "+balance);
				System.out.println("Remaining Balance in the Account : "+accNo+"  after transaction : "+remainingAmount);
				break;
			case 2:
				System.out.println("Thank You");
				break;
				default:
					System.out.println("Select Any One");
					break;
			}
			
		}
			
	    catch(Exception ee)
		{
			
		}
		}
			else
			{
				throw new AccountException(accNo1);
			}
			break;
			}
			catch(AccountException ex)
			{
				System.out.println("Given Account Number  not exists,Enter Valid Account Number");
			}
			}
			
		}
		else
		{
			String bal =String.valueOf(amount);
			throw new AccountException(bal);
		}
		break;
		}
		catch(AccountException ex)
		{
			System.out.println("No Sufficient Balance");
		}
			}
		}
		else
		{
			throw new AccountException(accNo);
		}
		break;
		}
		catch(AccountException e)
		{
			System.out.println("Given Account Number  not exists,Enter Valid Account Number");
		}
     }
	}
	public static void createAccount() throws ClassNotFoundException, SQLException{
	while(true)
	{
     System.out.println("Enter Customer Name");
	 String cusName=sc.next();
	 try
	 {
	 if(accService.validateCustomerName(cusName))
	 {
		while(true)
		{
		 System.out.println("Enter Customer Mobile Number");
		 String cusNo = sc.next();
		 try
		 {
		 if(accService.validateCustomerNumber(cusNo))
		 {
			 while(true)
			 {
			 System.out.println("Enter Customer Age");
			 int age = sc.nextInt();
			 try
			 {
			 if(age>18)
			 {
				 while(true)
				 {
				 System.out.println("Enter Customer gmail Id");
				 String mailId=sc.next();
				 try
				 {
				 if(accService.validateCustomerMailId(mailId))
				 {
					 while(true)
					 {
					 System.out.println("Enter Customer Aadhar Number");
					 String aadharNo = sc.next();
					 try
					 {
					 if(accService.validateCustomerAadharNo(aadharNo))
					 {
						 System.out.println("Enter Customer City");
						 String city = sc.next();
						 System.out.println("Enter Customer Pincode");
						 int pinCode= sc.nextInt();
					    
					    int max= 999999999;
					    int min = 0;
					    int range = (max-min);
					    int accNo = (int)(Math.random()*range);
					    String accNumber = String.valueOf(accNo);
					    System.out.println("Enter initial amount to deposit");
					    double amount = sc.nextDouble();
					   Customer c = new Customer(cusName,cusNo,age,mailId,aadharNo,city,pinCode,accNumber);
					    Account acc=new Account(accNumber,amount);
                        String accNum= accService.createAccount(c, acc);
                        System.out.println("Your Account Successfully Created  "+accNum+ "\n Bank Name : "+acc.getBankName()+"\n Branch Name :"+acc.getBranch()+" \n IFSC Code "+acc.getIfscCode()+" \n Account Balance :"+acc.getAccbalance());
					 }
					 else
					 {
						 throw new CustomerException(aadharNo);
					 }
					 break;
					 }
					 catch(CustomerException c)
					 {
						 System.out.println("Aadhar Number is not valid it must be 12 digits");
					 }
					 }
				 }
				 else
				 {
					 throw new CustomerException(mailId);
				 }
				 break;
				 }
				 catch(CustomerException e)
				 {
					 System.out.println("Enter Valid MailID");
				 }
				 }
			 }
			 else
			 {
				 String age1 = String.valueOf(age);
				 throw new CustomerException(age1);
			 }
			 break;
			 }
			 catch(CustomerException c)
			 {
				 System.out.println("Age must be greater than 18");
			 }
			 }
		 }
		 else
		 {
			 throw new CustomerException(cusNo);
		 }
		 break;
		 }
		 catch(CustomerException ex)
		 {
			System.out.println("Number of digits should be 10");
		 }
		}
	 }
	 else
	 {
		 throw new CustomerException(cusName);
	  }
	 break;
	 }
	  catch(CustomerException exc)
	 {
		System.out.println("Starting letter should be capital and maximum letters should be 12");
	 }
   }
	}
	public static void showBalance() throws ClassNotFoundException, SQLException{
     while(true)
     {
		System.out.println("Enter Account Number");
		String accNo = sc.next();
		
		double balance =accService.showBalance(accNo);
		try
		{
		if(balance!=0)
		{
		System.out.println("Balance in the Account is");
		System.out.println(balance);
		}
		else
		{
		throw new AccountException(accNo);	
		}
		break;
		}
		catch(AccountException e)
		{
			System.out.println("Given Account Number  not exists");
		}
     }
     }
	public static void deposit() throws ClassNotFoundException, SQLException {
	while(true)
	{
    System.out.println("Enter Account Number");
	String accNo = sc.next();
	double actualAmount = accService.showBalance(accNo);
	try
	{
	if(actualAmount!=0)
	{
		System.out.println("Enter Amount");
		double amount = sc.nextDouble();
	double balance = accService.deposit(accNo, amount);
	System.out.println("Successfully Deposited");
	System.out.println("Print Transactions\n");
	System.out.println("1.Yes \t 2.No");
	System.out.println("Enter Your Choice");
	int ch = sc.nextInt();
	switch(ch)
	{
	case 1:
		System.out.println("Balance in the Account before Deposit "+actualAmount);
		System.out.println("Remaining Balance in the Account after Deposited "+balance);
		break;
	case 2:
		System.out.println("Thank You");

		break;
		default:
			System.out.println("Select Any One");
			break;
	}
	}
	else
	{
		throw new AccountException(accNo);	
	}
	break;
	}
	catch(AccountException e)
	{
		System.out.println("Given Account Number  not exists");
	}
	}
	}
	public static void withDraw() throws ClassNotFoundException, SQLException{
     while(true)
     {
		System.out.println("Enter the Account Number");
		String  accNo = sc.next();
		double accBalance = accService.showBalance(accNo);
		double amount = 0;
		try
		{
		if(accBalance!=0)
		{
			while(true)
			{
			System.out.println("Enter the amount");
			 amount = sc.nextDouble();
			try
			{
			if(amount<accBalance)
			{
			double remainingBalance = accService.withDraw(accNo, amount);
		    System.out.println("Successfully Withdrawn");
		   
		     System.out.println("Print Transactions\n");
		 	System.out.println("1.Yes \t 2.No \n");
		 	System.out.println("Enter Your Choice");
		 	int ch = sc.nextInt();
		 	switch(ch)
		 	{
		 	case 1:
		 		System.out.println("Balance in the Account before withdrawl "+accBalance);
		 		System.out.println("Remaining Balance in the Account after WithDrawl "+remainingBalance);
		 		break;
		 	case 2:
				System.out.println("Thank You");

		 		break;
		 		default:
		 			System.out.println("Select Any One");
		 			break;
		 	}
			}
			else
			{
				String bal = String.valueOf(amount);
				throw new AccountException(bal);
			}
			break;
			}
			catch(AccountException ee)
			{
				System.out.println("No Sufficient Balance");
			}
			}
		}
		else
		{
			String amount1 = String.valueOf(amount);
			throw new AccountException(amount1);
		}
		break;
		}
		catch(AccountException e)
		{
			System.out.println("Given Account Number Not Exists");
		}
     }

	}
	
}
