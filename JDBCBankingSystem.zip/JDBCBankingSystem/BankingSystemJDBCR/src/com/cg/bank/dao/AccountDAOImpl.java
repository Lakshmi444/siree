package com.cg.bank.dao;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.util.JDBC;

public class AccountDAOImpl implements AccountDAO{
	

	@Override
	public String createAccount(Customer c, Account acc) throws ClassNotFoundException, SQLException {
		Connection con=JDBC.connect();
		Statement stmt=con.createStatement();
		
		PreparedStatement pst1=con.prepareStatement("INSERT INTO CUSTOMER_JDBC VALUES(?,?,?,?,?,?,?,?)");
        pst1.setString(1, c.getAccNo());
		pst1.setString(2, c.getCusName());
		pst1.setString(3, c.getCusNumber());
		pst1.setInt(4, c.getCusAge());
		pst1.setString(5, c.getMailId());
		pst1.setString(6, c.getCity());
		pst1.setInt(7, c.getPinCode());
		pst1.setString(8, c.getCusAadharNo());
		
		pst1.execute();
		PreparedStatement pst=con.prepareStatement("INSERT INTO account_jdbc VALUES(?,?,?,?,?)");
		 pst.setString(1, acc.getBankName());
	        pst.setString(2, acc.getBranch());
	        pst.setString(3, acc.getIfscCode());
		 pst.setDouble(4, acc.getAccbalance());
        pst.setString(5, acc.getAccNumber());
       

		pst.execute();
	     con.commit();

		return acc.getAccNumber();
	}

	@Override
	public double showBalance(String accNo) throws ClassNotFoundException, SQLException{
		Connection con=JDBC.connect();
		Statement stmt =con.createStatement();
		ResultSet res =stmt.executeQuery("select accbal from account_jdbc where accno='"+accNo+"' ");
		double balance=0;
		while(res.next())
		{
			 balance=res.getDouble(1);
			    con.commit();

			return balance;
		}
		return  balance;
	}

	@Override
	public double deposit( String accNo,double amount) throws ClassNotFoundException, SQLException{
		Connection con=JDBC.connect();
		Statement stmt =con.createStatement();
		ResultSet res =stmt.executeQuery("select accbal from account_jdbc where accno='"+accNo+"' ");
		double balance1=0;
	     while(res.next())
	     {
		 double balance=res.getDouble(1);
		 balance1=balance+amount;
	     }
	     ResultSet res1 =stmt.executeQuery("update account_jdbc set accbal="+balance1+" where accno='"+accNo+"' ");
	     con.commit();
	    return  balance1;
   }



	@Override
	public double withDraw( String accNo,double amount) throws ClassNotFoundException, SQLException{
		Connection con=JDBC.connect();
		Statement stmt =con.createStatement();
		ResultSet res =stmt.executeQuery("select accbal from account_jdbc where accno='"+accNo+"' ");
		double balance1=0;
	     while(res.next())
	     {
		 double balance=res.getDouble(1);
		 balance1=balance-amount;
	     }
	     ResultSet res1 =stmt.executeQuery("update account_jdbc set accbal="+balance1+" where accno='"+accNo+"' ");
	     con.commit();

	    return  balance1;
	}

	@Override
	public double fundTransfer(String accNo,String accNo1, double amount) throws ClassNotFoundException, SQLException{
		Connection con=JDBC.connect();
		Statement stmt =con.createStatement();
		ResultSet res =stmt.executeQuery("select accbal from account_jdbc where accno='"+accNo+"' ");
		double balance1=0;
	     while(res.next())
	     {
		 double balance=res.getDouble(1);
		 balance1=balance-amount;
	     }
	     ResultSet res1 =stmt.executeQuery("update account_jdbc set accbal="+balance1+" where accno='"+accNo+"' ");
	     
	   
			ResultSet result =stmt.executeQuery("select accbal from account_jdbc where accno='"+accNo1+"' ");
			double balance11=0;
		     while(result.next())
		     {
			 double balance12=result.getDouble(1);
			 balance11=balance12+amount;
		     }
		     ResultSet res11 =stmt.executeQuery("update account_jdbc set accbal="+balance11+" where accno='"+accNo1+"' ");
	     con.commit();

	    return  balance1;
	
	}

	@Override
	public Account printTransactions(String accNo) throws ClassNotFoundException, SQLException{
		
		Connection con=JDBC.connect();
		Statement stmt =con.createStatement();
		ResultSet res =stmt.executeQuery("select * from account_jdbc where accno='"+accNo+"' ");
	    while(res.next())
		{
	    	/*String bankname=res.getString(1);
	    	String branch=res.getString(2);
	    	String ifscCode=res.getString(3);*/
	    	String accountno=res.getString(4);
		    double balance=res.getDouble(5);
		    Account acc = new Account(accountno,balance);
		    con.commit();
		    return acc;
		 }
	     return  null;
       }

}
