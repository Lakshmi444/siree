package com.cg.bank.test;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

import com.cg.bank.dao.AccountDAO;
import com.cg.bank.dao.AccountDAOImpl;
import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;



class AccountDAOImplTest {
	static AccountDAO accDAO=new AccountDAOImpl();
/* 	@Test
	public void createAccountTest(){
	Customer c = new Customer("Mounika","9874563215",25,"mounika@gmail.com","456321089654","Vij",523002,"983929185");
	Account acc = new Account("983929185",3354.0);
	
	String result=accDAO.createAccount(c,acc);
    assertEquals("983929185",result);
	
	} */
 	@Test
 	public void showBalance() throws ClassNotFoundException, SQLException 
 	{
 		double bal = accDAO.showBalance("750730661");
 		Assert.assertEquals(Double.doubleToLongBits(2712),Double.doubleToLongBits(bal));
 				
 	}
 	@Test
 	public void deposit() throws ClassNotFoundException, SQLException 
 	{
 		double bal = accDAO.deposit("750730661", 2000);
 		assertEquals(Double.doubleToLongBits(4512), Double.doubleToLongBits(bal));
 	}
 	@Test
 	public void withdraw() throws ClassNotFoundException, SQLException 
 	{
 		double bal = accDAO.withDraw("750730661", 100);
 		assertEquals(Double.doubleToLongBits(2712), Double.doubleToLongBits(bal));
 	}
 	@Test 
 	public void fundTransfer() throws ClassNotFoundException, SQLException 
 	{
 		double bal = accDAO.fundTransfer("750730661","699329229", 200);
 		assertEquals(Double.doubleToLongBits(2512), Double.doubleToLongBits(bal));
 }
}

