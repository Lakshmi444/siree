package com.cg.plp.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name="Product_Table")
public class Products implements Serializable{

	@Id
	int product_id;
	
	String product_name;
	
	int product_quantity;
	
	double product_price;
	
	String product_description;
	
	double product_rating;
	
	String category_name;
	
	String product_brand;
	
	int product_discount;
	
	int merchant_id;
	
	String image;

	public int getProduct_id() {
		return product_id;
	}

	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public int getProduct_quantity() {
		return product_quantity;
	}

	public void setProduct_quantity(int product_quantity) {
		this.product_quantity = product_quantity;
	}

	public double getProduct_price() {
		return product_price;
	}

	public void setProduct_price(double product_price) {
		this.product_price = product_price;
	}

	public String getProduct_description() {
		return product_description;
	}

	public void setProduct_description(String product_description) {
		this.product_description = product_description;
	}

	public double getProduct_rating() {
		return product_rating;
	}

	public void setProduct_rating(double product_rating) {
		this.product_rating = product_rating;
	}

	public String getCategory_name() {
		return category_name;
	}

	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}

	public String getProduct_brand() {
		return product_brand;
	}

	public void setProduct_brand(String product_brand) {
		this.product_brand = product_brand;
	}

	public int getProduct_discount() {
		return product_discount;
	}

	public void setProduct_discount(int product_discount) {
		this.product_discount = product_discount;
	}

	public int getMerchant_id() {
		return merchant_id;
	}

	public void setMerchant_id(int merchant_id) {
		this.merchant_id = merchant_id;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public Products(int product_id, String product_name, int product_quantity, double product_price,
			String product_description, double product_rating, String category_name, String product_brand,
			int product_discount, int merchant_id, String image) {
		super();
		this.product_id = product_id;
		this.product_name = product_name;
		this.product_quantity = product_quantity;
		this.product_price = product_price;
		this.product_description = product_description;
		this.product_rating = product_rating;
		this.category_name = category_name;
		this.product_brand = product_brand;
		this.product_discount = product_discount;
		this.merchant_id = merchant_id;
		this.image = image;
	}

	public Products() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
