package com.cg.plp.service;

import java.util.List;

import com.cg.plp.entity.Products;


public interface ProductService {

	public List<Products> findAll();
	public void create(Products product);
	public void delete();
}
